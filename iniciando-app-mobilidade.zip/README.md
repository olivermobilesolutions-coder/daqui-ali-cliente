# Daqui Ali - App de Mobilidade Urbana

Aplicativo de mobilidade urbana completo com funcionalidades de corridas, entregas e fretes.

## 🚀 Como rodar o projeto

### Pré-requisitos

- Node.js 18+ instalado
- npm ou yarn

### Instalação

1. Clone ou copie os arquivos para uma pasta
2. Abra o terminal na pasta do projeto
3. Instale as dependências:

```bash
npm install
```

4. Rode o projeto em modo de desenvolvimento:

```bash
npm run dev
```

5. Acesse no navegador: `http://localhost:5173`

### Build para produção

```bash
npm run build
```

O build será gerado na pasta `dist/`.

## 📱 Funcionalidades

### Passageiro

- **Moto Táxi**: Solicite corridas de moto com filtros de gênero do motorista e quantidade de motos
- **Carro**: Corridas de carro com opções de ar condicionado, música e categoria do veículo
- **Entregas**: Envie pacotes de forma rápida e segura
- **Fretes e Mudanças**: Solicite caminhonetes e caminhões
- **Excursões**: Vans e ônibus para grupos

### Carteira Digital

- Saldo em carteira
- Depósito via PIX
- Histórico de transações
- Gorjetas para motoristas

### Acompanhamento

- Status da corrida em tempo real
- Chat com motorista
- Informações do veículo e placa
- Botão de emergência

### Histórico

- Todas as corridas, entregas e fretes
- Filtros por tipo
- Repetir corrida
- Detalhes completos

### Perfil

- Editar dados pessoais
- Endereços salvos
- Código de indicação
- Configurações

## 🛠️ Tecnologias

- **React 19** - Biblioteca de UI
- **TypeScript** - Tipagem estática
- **Vite** - Build tool
- **Tailwind CSS 4** - Estilização
- **Framer Motion** - Animações
- **React Router** - Navegação
- **React Query** - Gerenciamento de estado
- **Radix UI** - Componentes acessíveis
- **Lucide Icons** - Ícones
- **date-fns** - Manipulação de datas

## 📁 Estrutura de Arquivos

```
src/
├── api/                  # Mock API client
├── components/           # Componentes reutilizáveis
│   ├── home/            # Componentes da home
│   ├── ride/            # Componentes de corrida
│   ├── tracking/        # Componentes de acompanhamento
│   └── ui/              # Componentes UI base
├── hooks/               # Hooks customizados
│   ├── useStore.ts      # Hooks de estado
│   └── useRideSimulation.ts # Simulação de corrida
├── lib/                 # Utilitários
│   ├── storage.ts       # Persistência localStorage
│   └── utils.ts         # Funções utilitárias
├── pages/               # Páginas da aplicação
│   ├── Home.tsx
│   ├── RideRequest.tsx
│   ├── RideTracking.tsx
│   ├── DeliveryRequest.tsx
│   ├── DeliveryTracking.tsx
│   ├── FreightRequest.tsx
│   ├── History.tsx
│   ├── Chat.tsx
│   ├── Wallet.tsx
│   ├── Profile.tsx
│   └── Notifications.tsx
├── utils/               # Utilitários gerais
├── App.tsx              # Componente principal
├── main.tsx             # Entry point
└── index.css            # Estilos globais
```

## 💾 Persistência de Dados

O app usa **localStorage** para persistir todos os dados localmente:

- Usuário e perfil
- Corridas
- Entregas
- Fretes
- Transações
- Endereços salvos
- Notificações
- Conversas de chat

## 🔄 Simulação

O app simula o comportamento completo de uma corrida:

1. **Busca de motorista** (2-4 segundos)
2. **Motorista aceito** - Mostra dados do motorista
3. **Motorista a caminho** - ETA atualizado
4. **Motorista chegou** - Notificação
5. **Em viagem** - Acompanhamento
6. **Corrida finalizada** - Modal de avaliação

## 🔗 Rotas

| Rota | Descrição |
|------|-----------|
| `/` | Home com serviços |
| `/RideRequest?type=moto` | Solicitar moto |
| `/RideRequest?type=car` | Solicitar carro |
| `/RideTracking?id=xxx` | Acompanhar corrida |
| `/DeliveryRequest` | Nova entrega |
| `/DeliveryTracking?id=xxx` | Acompanhar entrega |
| `/FreightRequest?type=freight` | Solicitar frete |
| `/FreightRequest?type=excursion` | Solicitar excursão |
| `/History` | Histórico |
| `/Chat` | Conversas |
| `/Wallet` | Carteira |
| `/Profile` | Perfil |
| `/Notifications` | Notificações |

## 🔮 Próximos Passos

Para integrar com app de motorista:

1. Substituir localStorage por API real (Firebase, Supabase, etc.)
2. Implementar autenticação real
3. Adicionar WebSocket para atualizações em tempo real
4. Implementar geolocalização real com Google Maps
5. Adicionar notificações push
6. Implementar pagamento real (Stripe, PagSeguro, etc.)

## 📄 Licença

Este projeto é apenas para demonstração e fins educacionais.
