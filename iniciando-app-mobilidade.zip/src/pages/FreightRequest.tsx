import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Truck, Bus, Plus, Trash2, MapPin, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import PaymentSelector from '@/components/ride/PaymentSelector';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';

interface User {
  wallet_balance?: number;
}

interface Item {
  name: string;
  quantity: number;
}

export default function FreightRequest() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const requestType = searchParams.get('type') || 'freight';

  const [user, setUser] = useState<User | null>(null);
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);

  const [category, setCategory] = useState(requestType === 'excursion' ? 'excursion' : 'freight');
  const [origin, setOrigin] = useState({ address: '' });
  const [destination, setDestination] = useState({ address: '' });
  const [items, setItems] = useState<Item[]>([{ name: '', quantity: 1 }]);
  const [passengers, setPassengers] = useState({ adults: 1, children: 0 });
  const [scheduledDate, setScheduledDate] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');
  const [offeredPrice, setOfferedPrice] = useState('');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('wallet');

  const isExcursion = category === 'excursion';

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.log('User not logged in');
    }
  };

  const addItem = () => {
    setItems([...items, { name: '', quantity: 1 }]);
  };

  const removeItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const updateItem = (index: number, field: keyof Item, value: string | number) => {
    const updated = [...items];
    updated[index] = { ...updated[index], [field]: value };
    setItems(updated);
  };

  const handleConfirm = async () => {
    setLoading(true);
    try {
      await base44.entities.FreightRequest.create({
        category,
        status: 'awaiting_quote',
        origin,
        destination,
        items: isExcursion ? null : items,
        passengers: isExcursion ? passengers : null,
        scheduled_date: `${scheduledDate}T${scheduledTime}`,
        offered_price: offeredPrice ? parseFloat(offeredPrice) : null,
        payment_method: paymentMethod,
        notes
      });

      navigate('/History');
    } catch (error) {
      console.error('Erro ao criar solicitação:', error);
    } finally {
      setLoading(false);
    }
  };

  const canProceed = () => {
    if (step === 1) return category;
    if (step === 2) return origin.address && destination.address;
    if (step === 3) {
      if (isExcursion) return passengers.adults > 0;
      return items.some(item => item.name);
    }
    if (step === 4) return scheduledDate && scheduledTime;
    if (step === 5) return paymentMethod;
    return false;
  };

  const categories = [
    { id: 'freight', label: 'Frete', description: 'Caminhonete', icon: Truck, color: 'bg-orange-100 text-orange-600' },
    { id: 'moving', label: 'Mudança', description: 'Caminhão', icon: Truck, color: 'bg-blue-100 text-blue-600' },
    { id: 'excursion', label: 'Excursão', description: 'Vans e Ônibus', icon: Bus, color: 'bg-purple-100 text-purple-600' },
  ];

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      {/* Header */}
      <div className="bg-white px-5 pt-12 pb-4 border-b border-slate-100">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
            className="rounded-xl"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex items-center gap-3">
            <div className={cn(
              "w-10 h-10 rounded-xl flex items-center justify-center",
              isExcursion ? "bg-purple-100" : "bg-orange-100"
            )}>
              {isExcursion ? (
                <Bus className="w-5 h-5 text-purple-600" />
              ) : (
                <Truck className="w-5 h-5 text-orange-600" />
              )}
            </div>
            <div>
              <h1 className="font-semibold text-slate-900">
                {isExcursion ? 'Vans e Ônibus' : 'Fretes e Mudanças'}
              </h1>
              <p className="text-xs text-slate-500">Passo {step} de 5</p>
            </div>
          </div>
        </div>

        {/* Progress */}
        <div className="flex gap-2 mt-4">
          {[1, 2, 3, 4, 5].map((s) => (
            <div
              key={s}
              className={`h-1 flex-1 rounded-full transition-colors ${
                s <= step ? (isExcursion ? 'bg-purple-600' : 'bg-orange-600') : 'bg-slate-200'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="p-5 space-y-4">
        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
                <h3 className="font-semibold text-slate-900 mb-4">Tipo de serviço</h3>
                <div className="space-y-3">
                  {categories.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setCategory(cat.id)}
                      className={cn(
                        "w-full flex items-center gap-4 p-4 rounded-xl border-2 text-left transition-all",
                        category === cat.id
                          ? "border-blue-600 bg-blue-50"
                          : "border-slate-200 hover:border-slate-300"
                      )}
                    >
                      <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center", cat.color)}>
                        <cat.icon className="w-6 h-6" />
                      </div>
                      <div>
                        <p className="font-medium text-slate-900">{cat.label}</p>
                        <p className="text-sm text-slate-500">{cat.description}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
                <h3 className="font-semibold text-slate-900 mb-4">Localização</h3>
                <div className="space-y-4">
                  <div>
                    <Label className="text-xs text-slate-500">Origem</Label>
                    <div className="relative mt-1">
                      <Input
                        placeholder="Endereço de origem"
                        value={origin.address}
                        onChange={(e) => setOrigin({ ...origin, address: e.target.value })}
                        className="h-12 rounded-xl pl-10"
                      />
                      <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-blue-500" />
                    </div>
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500">Destino</Label>
                    <div className="relative mt-1">
                      <Input
                        placeholder="Endereço de destino"
                        value={destination.address}
                        onChange={(e) => setDestination({ ...destination, address: e.target.value })}
                        className="h-12 rounded-xl pl-10"
                      />
                      <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-500" />
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              {isExcursion ? (
                <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
                  <h3 className="font-semibold text-slate-900 mb-4">Passageiros</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
                      <div className="flex items-center gap-3">
                        <Users className="w-5 h-5 text-slate-600" />
                        <span className="font-medium">Adultos</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <Button
                          size="icon"
                          variant="outline"
                          onClick={() => setPassengers({ ...passengers, adults: Math.max(1, passengers.adults - 1) })}
                          className="h-8 w-8 rounded-lg"
                        >
                          -
                        </Button>
                        <span className="w-8 text-center font-semibold">{passengers.adults}</span>
                        <Button
                          size="icon"
                          variant="outline"
                          onClick={() => setPassengers({ ...passengers, adults: passengers.adults + 1 })}
                          className="h-8 w-8 rounded-lg"
                        >
                          +
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
                      <div className="flex items-center gap-3">
                        <Users className="w-5 h-5 text-slate-600" />
                        <span className="font-medium">Crianças</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <Button
                          size="icon"
                          variant="outline"
                          onClick={() => setPassengers({ ...passengers, children: Math.max(0, passengers.children - 1) })}
                          className="h-8 w-8 rounded-lg"
                        >
                          -
                        </Button>
                        <span className="w-8 text-center font-semibold">{passengers.children}</span>
                        <Button
                          size="icon"
                          variant="outline"
                          onClick={() => setPassengers({ ...passengers, children: passengers.children + 1 })}
                          className="h-8 w-8 rounded-lg"
                        >
                          +
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold text-slate-900">Lista de itens</h3>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={addItem}
                      className="rounded-xl"
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Adicionar
                    </Button>
                  </div>
                  <div className="space-y-3">
                    {items.map((item, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <Input
                          placeholder="Ex: Sofá, Geladeira..."
                          value={item.name}
                          onChange={(e) => updateItem(index, 'name', e.target.value)}
                          className="flex-1 h-11 rounded-xl"
                        />
                        <Input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(e) => updateItem(index, 'quantity', parseInt(e.target.value) || 1)}
                          className="w-20 h-11 rounded-xl text-center"
                        />
                        {items.length > 1 && (
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => removeItem(index)}
                            className="text-red-500 hover:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {step === 4 && (
            <motion.div
              key="step4"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
                <h3 className="font-semibold text-slate-900 mb-4">Agendamento</h3>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-xs text-slate-500">Data</Label>
                    <div className="relative mt-1">
                      <Input
                        type="date"
                        value={scheduledDate}
                        onChange={(e) => setScheduledDate(e.target.value)}
                        className="h-12 rounded-xl"
                      />
                    </div>
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500">Horário</Label>
                    <div className="relative mt-1">
                      <Input
                        type="time"
                        value={scheduledTime}
                        onChange={(e) => setScheduledTime(e.target.value)}
                        className="h-12 rounded-xl"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
                <h3 className="font-semibold text-slate-900 mb-3">Observações</h3>
                <Textarea
                  placeholder="Informações adicionais..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="rounded-xl"
                  rows={3}
                />
              </div>
            </motion.div>
          )}

          {step === 5 && (
            <motion.div
              key="step5"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
                <h3 className="font-semibold text-slate-900 mb-3">Sua oferta de valor (opcional)</h3>
                <p className="text-sm text-slate-500 mb-3">
                  Informe quanto você deseja pagar ou aguarde um orçamento
                </p>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 font-medium">
                    R$
                  </span>
                  <Input
                    type="number"
                    placeholder="0,00"
                    value={offeredPrice}
                    onChange={(e) => setOfferedPrice(e.target.value)}
                    className="h-14 rounded-xl pl-12 text-xl font-semibold"
                  />
                </div>
              </div>

              <PaymentSelector
                selected={paymentMethod}
                onSelect={setPaymentMethod}
                walletBalance={user?.wallet_balance || 0}
              />

              {/* Summary */}
              <div className="bg-slate-900 rounded-2xl p-5 text-white">
                <h3 className="font-semibold mb-4">Resumo da solicitação</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Tipo</span>
                    <span>{categories.find(c => c.id === category)?.label}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Data</span>
                    <span>{scheduledDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Horário</span>
                    <span>{scheduledTime}</span>
                  </div>
                  {isExcursion ? (
                    <div className="flex justify-between">
                      <span className="text-slate-400">Passageiros</span>
                      <span>{passengers.adults + passengers.children}</span>
                    </div>
                  ) : (
                    <div className="flex justify-between">
                      <span className="text-slate-400">Itens</span>
                      <span>{items.filter(i => i.name).length}</span>
                    </div>
                  )}
                </div>
                {offeredPrice && (
                  <div className="mt-4 pt-4 border-t border-slate-700">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Sua oferta</span>
                      <span className="text-xl font-bold">
                        R$ {parseFloat(offeredPrice).toFixed(2).replace('.', ',')}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              <Button
                onClick={handleConfirm}
                disabled={loading}
                className={cn(
                  "w-full h-14 rounded-xl text-white font-semibold",
                  isExcursion ? "bg-purple-600 hover:bg-purple-700" : "bg-orange-600 hover:bg-orange-700"
                )}
              >
                {loading ? 'Enviando...' : 'Enviar solicitação'}
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Bottom Actions */}
      {step < 5 && (
        <div className="fixed bottom-0 left-0 right-0 p-5 bg-white border-t border-slate-100">
          <div className="flex gap-3">
            {step > 1 && (
              <Button
                variant="outline"
                onClick={() => setStep(step - 1)}
                className="h-14 px-6 rounded-xl"
              >
                Voltar
              </Button>
            )}
            <Button
              onClick={() => setStep(step + 1)}
              disabled={!canProceed()}
              className={cn(
                "flex-1 h-14 rounded-xl text-white font-semibold",
                isExcursion ? "bg-purple-600 hover:bg-purple-700" : "bg-orange-600 hover:bg-orange-700"
              )}
            >
              Continuar
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
