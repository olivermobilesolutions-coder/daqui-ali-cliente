import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser, usePriceCalculation } from '@/hooks/useStore';
import * as storage from '@/lib/storage';
import { ArrowLeft, Package, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import PaymentSelector from '@/components/ride/PaymentSelector';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';

export default function DeliveryRequest() {
  const navigate = useNavigate();
  const { user } = useUser();
  const { calculateDeliveryPrice, estimateDistance } = usePriceCalculation();
  
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);

  const [origin, setOrigin] = useState({ address: '', contact_name: '', contact_phone: '' });
  const [destination, setDestination] = useState({ address: '', contact_name: '', contact_phone: '' });
  const [packageInfo, setPackageInfo] = useState({ description: '', weight: '', size: 'small' as 'small' | 'medium' | 'large' });
  const [paymentMethod, setPaymentMethod] = useState('wallet');

  // Calculate price based on inputs
  const distance = origin.address && destination.address 
    ? estimateDistance(origin.address, destination.address) 
    : 0;
  const estimatedPrice = distance > 0 
    ? calculateDeliveryPrice(distance, packageInfo.size) 
    : 12.50;

  const handleConfirm = async () => {
    setLoading(true);
    try {
      // Check wallet balance
      if (paymentMethod === 'wallet' && (user?.wallet_balance || 0) < estimatedPrice) {
        alert('Saldo insuficiente na carteira.');
        setLoading(false);
        return;
      }

      // Create delivery
      const delivery = storage.createDelivery({
        status: 'pending',
        origin,
        destination,
        package_info: packageInfo,
        price: estimatedPrice,
        payment_method: paymentMethod
      });

      // Deduct from wallet if applicable
      if (paymentMethod === 'wallet') {
        storage.deductBalance(estimatedPrice);
        storage.createTransaction({
          type: 'payment',
          amount: -estimatedPrice,
          description: 'Entrega',
          reference_id: delivery.id,
          reference_type: 'delivery',
        });
      }

      navigate('/DeliveryTracking?id=' + delivery.id);
    } catch (error) {
      console.error('Erro ao criar entrega:', error);
      alert('Erro ao criar entrega. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const canProceed = () => {
    if (step === 1) return origin.address && origin.contact_name;
    if (step === 2) return destination.address && destination.contact_name;
    if (step === 3) return packageInfo.description;
    if (step === 4) return paymentMethod;
    return false;
  };

  const sizes = [
    { id: 'small' as const, label: 'Pequeno', description: 'Até 5kg', icon: '📦' },
    { id: 'medium' as const, label: 'Médio', description: '5-15kg', icon: '📦' },
    { id: 'large' as const, label: 'Grande', description: '15-30kg', icon: '📦' }
  ];

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      {/* Header */}
      <div className="bg-white px-5 pt-12 pb-4 border-b border-slate-100">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
            className="rounded-xl"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center">
              <Package className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <h1 className="font-semibold text-slate-900">Entrega</h1>
              <p className="text-xs text-slate-500">Passo {step} de 4</p>
            </div>
          </div>
        </div>

        {/* Progress */}
        <div className="flex gap-2 mt-4">
          {[1, 2, 3, 4].map((s) => (
            <div
              key={s}
              className={`h-1 flex-1 rounded-full transition-colors ${
                s <= step ? 'bg-emerald-600' : 'bg-slate-200'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="p-5 space-y-4">
        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
                <h3 className="font-semibold text-slate-900 mb-4">📍 Coleta (Origem)</h3>
                <div className="space-y-4">
                  <div>
                    <Label className="text-xs text-slate-500">Endereço de coleta</Label>
                    <div className="relative mt-1">
                      <Input
                        placeholder="Rua, número, bairro..."
                        value={origin.address}
                        onChange={(e) => setOrigin({ ...origin, address: e.target.value })}
                        className="h-12 rounded-xl pl-10"
                      />
                      <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-blue-500" />
                    </div>
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500">Nome do contato</Label>
                    <Input
                      placeholder="Quem vai entregar o pacote?"
                      value={origin.contact_name}
                      onChange={(e) => setOrigin({ ...origin, contact_name: e.target.value })}
                      className="h-12 rounded-xl mt-1"
                    />
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500">Telefone (opcional)</Label>
                    <Input
                      placeholder="(00) 00000-0000"
                      value={origin.contact_phone}
                      onChange={(e) => setOrigin({ ...origin, contact_phone: e.target.value })}
                      className="h-12 rounded-xl mt-1"
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
                <h3 className="font-semibold text-slate-900 mb-4">📦 Entrega (Destino)</h3>
                <div className="space-y-4">
                  <div>
                    <Label className="text-xs text-slate-500">Endereço de entrega</Label>
                    <div className="relative mt-1">
                      <Input
                        placeholder="Rua, número, bairro..."
                        value={destination.address}
                        onChange={(e) => setDestination({ ...destination, address: e.target.value })}
                        className="h-12 rounded-xl pl-10"
                      />
                      <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-500" />
                    </div>
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500">Nome do destinatário</Label>
                    <Input
                      placeholder="Quem vai receber o pacote?"
                      value={destination.contact_name}
                      onChange={(e) => setDestination({ ...destination, contact_name: e.target.value })}
                      className="h-12 rounded-xl mt-1"
                    />
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500">Telefone (opcional)</Label>
                    <Input
                      placeholder="(00) 00000-0000"
                      value={destination.contact_phone}
                      onChange={(e) => setDestination({ ...destination, contact_phone: e.target.value })}
                      className="h-12 rounded-xl mt-1"
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
                <h3 className="font-semibold text-slate-900 mb-4">📋 Sobre o pacote</h3>
                <div className="space-y-4">
                  <div>
                    <Label className="text-xs text-slate-500">O que você está enviando?</Label>
                    <Textarea
                      placeholder="Descreva o conteúdo do pacote..."
                      value={packageInfo.description}
                      onChange={(e) => setPackageInfo({ ...packageInfo, description: e.target.value })}
                      className="rounded-xl mt-1"
                      rows={3}
                    />
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500 mb-3 block">Tamanho do pacote</Label>
                    <div className="grid grid-cols-3 gap-3">
                      {sizes.map((size) => (
                        <button
                          key={size.id}
                          onClick={() => setPackageInfo({ ...packageInfo, size: size.id })}
                          className={cn(
                            "p-4 rounded-xl border-2 text-center transition-all",
                            packageInfo.size === size.id
                              ? "border-emerald-600 bg-emerald-50"
                              : "border-slate-200 hover:border-slate-300"
                          )}
                        >
                          <span className="text-2xl">{size.icon}</span>
                          <p className="font-medium text-sm mt-2">{size.label}</p>
                          <p className="text-xs text-slate-500">{size.description}</p>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {step === 4 && (
            <motion.div
              key="step4"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <PaymentSelector
                selected={paymentMethod}
                onSelect={setPaymentMethod}
                walletBalance={user?.wallet_balance || 0}
              />

              {/* Summary */}
              <div className="bg-slate-900 rounded-2xl p-5 text-white">
                <h3 className="font-semibold mb-4">📋 Resumo da entrega</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex items-start gap-3">
                    <MapPin className="w-4 h-4 text-blue-400 mt-0.5" />
                    <div>
                      <p className="text-slate-400">Coleta</p>
                      <p>{origin.address}</p>
                      <p className="text-xs text-slate-500">Contato: {origin.contact_name}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <MapPin className="w-4 h-4 text-emerald-400 mt-0.5" />
                    <div>
                      <p className="text-slate-400">Entrega</p>
                      <p>{destination.address}</p>
                      <p className="text-xs text-slate-500">Destinatário: {destination.contact_name}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Package className="w-4 h-4 text-purple-400 mt-0.5" />
                    <div>
                      <p className="text-slate-400">Pacote</p>
                      <p>{packageInfo.description}</p>
                      <p className="text-xs text-slate-500">
                        Tamanho: {sizes.find(s => s.id === packageInfo.size)?.label}
                      </p>
                    </div>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-slate-700">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Valor estimado</span>
                    <span className="text-2xl font-bold">
                      R$ {estimatedPrice.toFixed(2).replace('.', ',')}
                    </span>
                  </div>
                </div>
              </div>

              <Button
                onClick={handleConfirm}
                disabled={loading}
                className="w-full h-14 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold"
              >
                {loading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Confirmando...</span>
                  </div>
                ) : (
                  'Confirmar entrega'
                )}
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Bottom Actions */}
      {step < 4 && (
        <div className="fixed bottom-0 left-0 right-0 p-5 bg-white border-t border-slate-100">
          <div className="flex gap-3">
            {step > 1 && (
              <Button
                variant="outline"
                onClick={() => setStep(step - 1)}
                className="h-14 px-6 rounded-xl"
              >
                Voltar
              </Button>
            )}
            <Button
              onClick={() => setStep(step + 1)}
              disabled={!canProceed()}
              className="flex-1 h-14 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold"
            >
              Continuar
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
