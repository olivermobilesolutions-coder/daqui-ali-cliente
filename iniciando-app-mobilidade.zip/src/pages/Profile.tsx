import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser, useAddresses, useRides } from '@/hooks/useStore';
import * as storage from '@/lib/storage';
import { 
  Star, MapPin, Gift, Shield, 
  ChevronRight, LogOut, Bell, CreditCard, HelpCircle,
  Camera, Plus, Home, Briefcase, Trash2, Copy, Check,
  User, Phone, Mail, Edit2, Bike, Car
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

export default function Profile() {
  const navigate = useNavigate();
  const { user, loading, updateUser } = useUser();
  const { addresses, saveAddress, deleteAddress } = useAddresses();
  const { rides } = useRides();
  
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [showAddAddress, setShowAddAddress] = useState(false);
  const [showAddressManager, setShowAddressManager] = useState(false);
  const [editData, setEditData] = useState({ full_name: '', phone: '', email: '' });
  const [newAddress, setNewAddress] = useState<{ label: string; address: string; type: 'home' | 'work' | 'other' }>({ label: '', address: '', type: 'other' });
  const [saving, setSaving] = useState(false);
  const [copied, setCopied] = useState(false);

  // Statistics
  const motoRides = rides.filter(r => r.type === 'moto' && r.status === 'completed').length;
  const carRides = rides.filter(r => r.type === 'car' && r.status === 'completed').length;
  const totalRides = motoRides + carRides;

  const handleEditProfile = () => {
    setEditData({
      full_name: user?.full_name || '',
      phone: user?.phone || '',
      email: user?.email || ''
    });
    setShowEditProfile(true);
  };

  const handleSaveProfile = async () => {
    setSaving(true);
    try {
      updateUser(editData);
      setShowEditProfile(false);
    } catch (error) {
      console.error('Erro ao salvar:', error);
    } finally {
      setSaving(false);
    }
  };

  const handleSaveAddress = () => {
    if (newAddress.label && newAddress.address) {
      saveAddress(newAddress);
      setNewAddress({ label: '', address: '', type: 'other' });
      setShowAddAddress(false);
    }
  };

  const handleCopyReferralCode = () => {
    navigator.clipboard.writeText(user?.referral_code || '');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareReferral = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Daqui Ali - App de mobilidade',
        text: `Use meu código ${user?.referral_code || 'DAQUIALI'} no Daqui Ali e ganhe R$ 5 na sua primeira corrida!`,
        url: 'https://daquiali.com',
      });
    } else {
      handleCopyReferralCode();
    }
  };

  const handleLogout = () => {
    storage.clearAllData();
    window.location.href = '/';
  };

  const openWhatsApp = () => {
    window.open('https://wa.me/5511964527167?text=Olá! Preciso de ajuda com o app Daqui Ali.', '_blank');
  };

  const menuItems = [
    { icon: Bell, label: 'Notificações', action: () => navigate('/Notifications'), badge: undefined },
    { icon: CreditCard, label: 'Carteira', action: () => navigate('/Wallet'), badge: `R$ ${user?.wallet_balance?.toFixed(0) || 0}` },
    { icon: MapPin, label: 'Endereços salvos', action: () => setShowAddressManager(true), badge: addresses.length > 0 ? String(addresses.length) : undefined },
    { icon: Gift, label: 'Indicar amigos', action: handleShareReferral, badge: 'R$ 5' },
    { icon: Shield, label: 'Privacidade e segurança', action: () => {}, badge: undefined },
    { icon: HelpCircle, label: 'Ajuda e suporte', action: openWhatsApp, badge: undefined },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-8">
      {/* Header */}
      <div className="bg-white px-5 pt-12 pb-6">
        <h1 className="text-2xl font-bold text-slate-900 mb-6">Perfil</h1>

        {/* User Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4"
        >
          <div className="relative">
            <Avatar className="w-20 h-20 ring-4 ring-blue-100">
              <AvatarImage src={user?.photo} />
              <AvatarFallback className="bg-blue-100 text-blue-600 text-2xl font-bold">
                {user?.full_name?.charAt(0) || 'U'}
              </AvatarFallback>
            </Avatar>
            <button className="absolute -bottom-1 -right-1 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center shadow-lg">
              <Camera className="w-4 h-4 text-white" />
            </button>
          </div>
          
          <div className="flex-1">
            <h2 className="font-semibold text-slate-900 text-lg">
              {user?.full_name || 'Usuário'}
            </h2>
            <p className="text-slate-500 text-sm">{user?.email}</p>
            <div className="flex items-center gap-2 mt-2">
              <div className="flex items-center gap-1 bg-amber-50 px-2 py-1 rounded-full">
                <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                <span className="text-xs font-medium text-amber-700">
                  {user?.rating?.toFixed(1) || '5.0'}
                </span>
              </div>
              <span className="text-xs text-slate-400">
                • {totalRides} corridas
              </span>
            </div>
          </div>

          <Button
            variant="outline"
            size="icon"
            onClick={handleEditProfile}
            className="rounded-xl"
          >
            <Edit2 className="w-4 h-4" />
          </Button>
        </motion.div>

        {/* Stats */}
        <div className="flex gap-3 mt-6">
          <div className="flex-1 bg-blue-50 rounded-xl p-3 flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
              <Bike className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-xs text-blue-600">Moto</p>
              <p className="font-bold text-blue-900">{motoRides}</p>
            </div>
          </div>
          <div className="flex-1 bg-indigo-50 rounded-xl p-3 flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-100 rounded-xl flex items-center justify-center">
              <Car className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <p className="text-xs text-indigo-600">Carro</p>
              <p className="font-bold text-indigo-900">{carRides}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Referral Code */}
      <div className="px-5 py-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-2xl p-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-200 text-sm">Seu código de indicação</p>
              <p className="text-white text-xl font-bold font-mono">{user?.referral_code || 'USUARIO123'}</p>
              <p className="text-purple-200 text-xs mt-1">Ganhe R$ 5 por cada amigo</p>
            </div>
            <Button
              variant="secondary"
              size="sm"
              onClick={handleShareReferral}
              className="rounded-xl bg-white text-purple-600 hover:bg-purple-50"
            >
              {copied ? <Check className="w-4 h-4 mr-1" /> : <Copy className="w-4 h-4 mr-1" />}
              {copied ? 'Copiado!' : 'Compartilhar'}
            </Button>
          </div>
        </motion.div>
      </div>

      {/* Quick Addresses */}
      {addresses.length > 0 && (
        <div className="px-5 mb-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-slate-900">Endereços favoritos</h3>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowAddressManager(true)}
              className="text-blue-600"
            >
              Ver todos
            </Button>
          </div>
          <div className="flex gap-3 overflow-x-auto pb-2">
            {addresses.slice(0, 3).map((addr) => (
              <div
                key={addr.id}
                className="bg-white rounded-xl p-3 flex items-center gap-3 min-w-[180px] border border-slate-100"
              >
                <div className={cn(
                  "w-10 h-10 rounded-xl flex items-center justify-center shrink-0",
                  addr.type === 'home' ? 'bg-blue-100' : addr.type === 'work' ? 'bg-purple-100' : 'bg-slate-100'
                )}>
                  {addr.type === 'home' ? (
                    <Home className="w-5 h-5 text-blue-600" />
                  ) : addr.type === 'work' ? (
                    <Briefcase className="w-5 h-5 text-purple-600" />
                  ) : (
                    <MapPin className="w-5 h-5 text-slate-600" />
                  )}
                </div>
                <div className="min-w-0">
                  <p className="font-medium text-slate-900 text-sm">{addr.label}</p>
                  <p className="text-xs text-slate-500 truncate">{addr.address.slice(0, 25)}...</p>
                </div>
              </div>
            ))}
            <button
              onClick={() => setShowAddAddress(true)}
              className="bg-slate-100 rounded-xl p-3 flex items-center gap-2 min-w-[120px] hover:bg-slate-200 transition-colors"
            >
              <Plus className="w-5 h-5 text-slate-500" />
              <span className="text-sm text-slate-600">Adicionar</span>
            </button>
          </div>
        </div>
      )}

      {/* Menu Items */}
      <div className="px-5">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-2xl overflow-hidden"
        >
          {menuItems.map((item) => (
            <button
              key={item.label}
              onClick={item.action}
              className="w-full flex items-center gap-4 p-4 hover:bg-slate-50 transition-colors border-b border-slate-100 last:border-b-0"
            >
              <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center">
                <item.icon className="w-5 h-5 text-slate-600" />
              </div>
              <span className="flex-1 text-left font-medium text-slate-900">{item.label}</span>
              {item.badge && (
                <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-xs font-semibold rounded-full">
                  {item.badge}
                </span>
              )}
              <ChevronRight className="w-5 h-5 text-slate-400" />
            </button>
          ))}
        </motion.div>
      </div>

      {/* Logout */}
      <div className="px-5 mt-4">
        <Button
          variant="outline"
          onClick={handleLogout}
          className="w-full h-12 rounded-xl border-red-200 text-red-600 hover:bg-red-50"
        >
          <LogOut className="w-5 h-5 mr-2" />
          Sair da conta
        </Button>
      </div>

      {/* App Version */}
      <p className="text-center text-xs text-slate-400 mt-6">
        Daqui Ali v1.0.0 • Feito com ❤️
      </p>

      {/* Edit Profile Modal */}
      <Dialog open={showEditProfile} onOpenChange={setShowEditProfile}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Editar perfil</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <label className="text-sm text-slate-500 mb-2 block flex items-center gap-2">
                <User className="w-4 h-4" />
                Nome completo
              </label>
              <Input
                value={editData.full_name}
                onChange={(e) => setEditData({ ...editData, full_name: e.target.value })}
                className="h-12 rounded-xl"
                placeholder="Seu nome"
              />
            </div>
            <div>
              <label className="text-sm text-slate-500 mb-2 block flex items-center gap-2">
                <Phone className="w-4 h-4" />
                Telefone
              </label>
              <Input
                value={editData.phone}
                onChange={(e) => setEditData({ ...editData, phone: e.target.value })}
                className="h-12 rounded-xl"
                placeholder="(00) 00000-0000"
              />
            </div>
            <div>
              <label className="text-sm text-slate-500 mb-2 block flex items-center gap-2">
                <Mail className="w-4 h-4" />
                E-mail
              </label>
              <Input
                value={editData.email}
                onChange={(e) => setEditData({ ...editData, email: e.target.value })}
                className="h-12 rounded-xl"
                placeholder="seu@email.com"
                type="email"
              />
            </div>

            <div className="flex gap-3 pt-2">
              <Button
                variant="outline"
                onClick={() => setShowEditProfile(false)}
                className="flex-1 h-12 rounded-xl"
              >
                Cancelar
              </Button>
              <Button
                onClick={handleSaveProfile}
                disabled={saving}
                className="flex-1 h-12 rounded-xl"
              >
                {saving ? 'Salvando...' : 'Salvar'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Address Manager Modal */}
      <Dialog open={showAddressManager} onOpenChange={setShowAddressManager}>
        <DialogContent className="sm:max-w-md max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Endereços salvos</DialogTitle>
          </DialogHeader>

          <div className="space-y-3">
            {addresses.length === 0 ? (
              <div className="text-center py-8">
                <MapPin className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <p className="text-slate-500">Nenhum endereço salvo</p>
              </div>
            ) : (
              addresses.map((addr) => (
                <div
                  key={addr.id}
                  className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl"
                >
                  <div className={cn(
                    "w-10 h-10 rounded-xl flex items-center justify-center shrink-0",
                    addr.type === 'home' ? 'bg-blue-100' : addr.type === 'work' ? 'bg-purple-100' : 'bg-slate-200'
                  )}>
                    {addr.type === 'home' ? (
                      <Home className="w-5 h-5 text-blue-600" />
                    ) : addr.type === 'work' ? (
                      <Briefcase className="w-5 h-5 text-purple-600" />
                    ) : (
                      <MapPin className="w-5 h-5 text-slate-600" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-slate-900">{addr.label}</p>
                    <p className="text-sm text-slate-500 truncate">{addr.address}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => deleteAddress(addr.id)}
                    className="text-red-500 hover:bg-red-50 shrink-0"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))
            )}

            <Button
              onClick={() => {
                setShowAddressManager(false);
                setShowAddAddress(true);
              }}
              className="w-full h-12 rounded-xl"
            >
              <Plus className="w-4 h-4 mr-2" />
              Adicionar endereço
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Address Modal */}
      <Dialog open={showAddAddress} onOpenChange={setShowAddAddress}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Adicionar endereço</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <label className="text-sm text-slate-500 mb-2 block">Tipo</label>
              <div className="flex gap-2">
                {[
                  { id: 'home' as const, label: 'Casa', icon: Home },
                  { id: 'work' as const, label: 'Trabalho', icon: Briefcase },
                  { id: 'other' as const, label: 'Outro', icon: MapPin },
                ].map((type) => (
                  <button
                    key={type.id}
                    onClick={() => setNewAddress({ ...newAddress, type: type.id })}
                    className={cn(
                      "flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border-2 transition-all",
                      newAddress.type === type.id
                        ? "border-blue-600 bg-blue-50 text-blue-600"
                        : "border-slate-200 text-slate-600"
                    )}
                  >
                    <type.icon className="w-4 h-4" />
                    <span className="text-sm font-medium">{type.label}</span>
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-sm text-slate-500 mb-2 block">Nome do local</label>
              <Input
                placeholder="Ex: Minha casa"
                value={newAddress.label}
                onChange={(e) => setNewAddress({ ...newAddress, label: e.target.value })}
                className="h-12 rounded-xl"
              />
            </div>
            <div>
              <label className="text-sm text-slate-500 mb-2 block">Endereço completo</label>
              <Input
                placeholder="Rua, número, bairro, cidade..."
                value={newAddress.address}
                onChange={(e) => setNewAddress({ ...newAddress, address: e.target.value })}
                className="h-12 rounded-xl"
              />
            </div>

            <div className="flex gap-3 pt-2">
              <Button
                variant="outline"
                onClick={() => setShowAddAddress(false)}
                className="flex-1 h-12 rounded-xl"
              >
                Cancelar
              </Button>
              <Button
                onClick={handleSaveAddress}
                disabled={!newAddress.label || !newAddress.address}
                className="flex-1 h-12 rounded-xl"
              >
                <Plus className="w-4 h-4 mr-1" />
                Salvar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
