import { useState, useEffect, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import * as storage from '@/lib/storage';
import { format } from 'date-fns';
import { 
  ArrowLeft, Send, Phone, 
  MessageCircle, CheckCheck, Bike, Package
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'driver';
  timestamp: string;
  read: boolean;
}

interface ChatSession {
  id: string;
  type: 'ride' | 'delivery';
  rideId?: string;
  deliveryId?: string;
  driver: storage.Driver;
  messages: Message[];
  lastMessage?: string;
  lastMessageTime?: string;
  unreadCount: number;
  status: string;
  origin?: string;
  destination?: string;
}

// Storage key for chats
const CHATS_KEY = 'daquiali_chats';

function getChats(): ChatSession[] {
  try {
    const data = localStorage.getItem(CHATS_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

function saveChats(chats: ChatSession[]): void {
  localStorage.setItem(CHATS_KEY, JSON.stringify(chats));
}

function generateQuickReplies(): string[] {
  return [
    'Estou a caminho!',
    'Já estou no local',
    'Pode aguardar um momento?',
    'Ok, entendido!',
    'Obrigado!',
  ];
}

function generateDriverReply(userMessage: string): string {
  const replies = [
    'Ok, entendido!',
    'Certo, já estou a caminho.',
    'Sem problemas!',
    'Perfeito, aguardo você.',
    'Beleza, pode deixar!',
    'Já estou chegando, só mais alguns minutos.',
    'Ok, vou aguardar aqui.',
    'Recebi sua mensagem, obrigado!',
  ];
  
  // Some contextual replies
  const lowerMessage = userMessage.toLowerCase();
  if (lowerMessage.includes('atras') || lowerMessage.includes('atrás')) {
    return 'Entendi, vou me posicionar!';
  }
  if (lowerMessage.includes('portão') || lowerMessage.includes('portao')) {
    return 'Certo, vou até o portão!';
  }
  if (lowerMessage.includes('espera') || lowerMessage.includes('aguard')) {
    return 'Sem problemas, estou aguardando aqui.';
  }
  if (lowerMessage.includes('obrigad')) {
    return 'Imagina, estamos às ordens! 😊';
  }
  
  return replies[Math.floor(Math.random() * replies.length)];
}

export default function Chat() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const chatId = searchParams.get('id');
  
  const [chats, setChats] = useState<ChatSession[]>([]);
  const [activeChat, setActiveChat] = useState<ChatSession | null>(null);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(true);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Load chats and create from active rides/deliveries
  useEffect(() => {
    loadChats();
  }, []);

  // Handle chatId from URL
  useEffect(() => {
    if (chatId && chats.length > 0) {
      const chat = chats.find(c => c.id === chatId);
      if (chat) {
        setActiveChat(chat);
        // Mark messages as read
        markChatAsRead(chatId);
      }
    }
  }, [chatId, chats]);

  // Scroll to bottom when messages change
  useEffect(() => {
    scrollToBottom();
  }, [activeChat?.messages]);

  const loadChats = () => {
    // Get existing chats
    let existingChats = getChats();
    
    // Check for active rides/deliveries that should have chats
    const rides = storage.getRides();
    const deliveries = storage.getDeliveries();
    
    // Create chats for rides with drivers
    rides.forEach(ride => {
      if (ride.driver && !['completed', 'cancelled'].includes(ride.status)) {
        const existingChat = existingChats.find(c => c.rideId === ride.id);
        if (!existingChat) {
          const newChat: ChatSession = {
            id: `ride-${ride.id}`,
            type: 'ride',
            rideId: ride.id,
            driver: ride.driver,
            messages: [{
              id: '1',
              text: `Olá! Sou ${ride.driver.name}, seu motorista. Estou a caminho!`,
              sender: 'driver',
              timestamp: new Date().toISOString(),
              read: false,
            }],
            lastMessage: `Olá! Sou ${ride.driver.name}, seu motorista.`,
            lastMessageTime: new Date().toISOString(),
            unreadCount: 1,
            status: ride.status,
            origin: ride.origin?.address,
            destination: ride.destination?.address,
          };
          existingChats = [newChat, ...existingChats];
        } else {
          // Update status
          existingChat.status = ride.status;
        }
      }
    });

    // Create chats for deliveries with drivers
    deliveries.forEach(delivery => {
      if (delivery.driver && !['delivered', 'cancelled'].includes(delivery.status)) {
        const existingChat = existingChats.find(c => c.deliveryId === delivery.id);
        if (!existingChat) {
          const newChat: ChatSession = {
            id: `delivery-${delivery.id}`,
            type: 'delivery',
            deliveryId: delivery.id,
            driver: delivery.driver,
            messages: [{
              id: '1',
              text: `Olá! Sou ${delivery.driver.name}. Vou fazer sua entrega!`,
              sender: 'driver',
              timestamp: new Date().toISOString(),
              read: false,
            }],
            lastMessage: `Olá! Sou ${delivery.driver.name}.`,
            lastMessageTime: new Date().toISOString(),
            unreadCount: 1,
            status: delivery.status,
            origin: delivery.origin?.address,
            destination: delivery.destination?.address,
          };
          existingChats = [newChat, ...existingChats];
        } else {
          existingChat.status = delivery.status;
        }
      }
    });

    saveChats(existingChats);
    setChats(existingChats);
    setLoading(false);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const markChatAsRead = (id: string) => {
    const updatedChats = chats.map(c => {
      if (c.id === id) {
        return {
          ...c,
          unreadCount: 0,
          messages: c.messages.map(m => ({ ...m, read: true })),
        };
      }
      return c;
    });
    setChats(updatedChats);
    saveChats(updatedChats);
  };

  const handleSendMessage = () => {
    if (!message.trim() || !activeChat) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      text: message.trim(),
      sender: 'user',
      timestamp: new Date().toISOString(),
      read: true,
    };

    // Update chat with new message
    const updatedChat: ChatSession = {
      ...activeChat,
      messages: [...activeChat.messages, newMessage],
      lastMessage: message.trim(),
      lastMessageTime: new Date().toISOString(),
    };

    setActiveChat(updatedChat);
    setChats(prev => prev.map(c => c.id === activeChat.id ? updatedChat : c));
    saveChats(chats.map(c => c.id === activeChat.id ? updatedChat : c));
    setMessage('');

    // Simulate driver reply after 1-3 seconds
    setTimeout(() => {
      const driverReply: Message = {
        id: (Date.now() + 1).toString(),
        text: generateDriverReply(message),
        sender: 'driver',
        timestamp: new Date().toISOString(),
        read: true,
      };

      setActiveChat(prev => {
        if (!prev) return null;
        const updated = {
          ...prev,
          messages: [...prev.messages, driverReply],
          lastMessage: driverReply.text,
          lastMessageTime: driverReply.timestamp,
        };
        setChats(chats => chats.map(c => c.id === prev.id ? updated : c));
        saveChats(chats.map(c => c.id === prev.id ? updated : c));
        return updated;
      });
    }, 1000 + Math.random() * 2000);

    // Focus input
    inputRef.current?.focus();
  };

  const handleQuickReply = (text: string) => {
    setMessage(text);
    setTimeout(() => handleSendMessage(), 100);
  };

  const handleCallDriver = () => {
    if (activeChat?.driver?.phone) {
      window.open(`tel:${activeChat.driver.phone}`);
    }
  };

  const handleOpenChat = (chat: ChatSession) => {
    setActiveChat(chat);
    markChatAsRead(chat.id);
    navigate(`/Chat?id=${chat.id}`, { replace: true });
  };

  const handleBack = () => {
    if (activeChat) {
      setActiveChat(null);
      navigate('/Chat', { replace: true });
    } else {
      navigate(-1);
    }
  };

  // Chat list view
  if (!activeChat) {
    return (
      <div className="min-h-screen bg-slate-50">
        {/* Header */}
        <div className="bg-white px-5 pt-12 pb-4 border-b border-slate-100">
          <h1 className="text-2xl font-bold text-slate-900">Mensagens</h1>
          <p className="text-sm text-slate-500">Converse com seus motoristas</p>
        </div>

        {/* Chat List */}
        <div className="p-5">
          {loading ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => (
                <div key={i} className="bg-white rounded-2xl p-4 animate-pulse">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-slate-200 rounded-full" />
                    <div className="flex-1">
                      <div className="h-4 bg-slate-200 rounded w-1/3 mb-2" />
                      <div className="h-3 bg-slate-200 rounded w-2/3" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : chats.length === 0 ? (
            <div className="text-center py-16">
              <MessageCircle className="w-16 h-16 text-slate-300 mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-slate-900 mb-2">Sem conversas</h2>
              <p className="text-slate-500 mb-4">
                Suas conversas com motoristas aparecerão aqui.
              </p>
              <Button onClick={() => navigate('/')}>
                Solicitar corrida
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {chats.map((chat, index) => (
                <motion.div
                  key={chat.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => handleOpenChat(chat)}
                  className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 cursor-pointer hover:shadow-md transition-all"
                >
                  <div className="flex items-center gap-4">
                    <div className="relative">
                      <Avatar className="w-14 h-14">
                        <AvatarImage src={chat.driver.photo} />
                        <AvatarFallback className="bg-blue-100 text-blue-600 text-lg font-bold">
                          {chat.driver.name.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div className={cn(
                        "absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center",
                        chat.type === 'ride' ? 'bg-blue-100' : 'bg-emerald-100'
                      )}>
                        {chat.type === 'ride' ? (
                          <Bike className="w-3 h-3 text-blue-600" />
                        ) : (
                          <Package className="w-3 h-3 text-emerald-600" />
                        )}
                      </div>
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="font-semibold text-slate-900">{chat.driver.name}</h3>
                        {chat.lastMessageTime && (
                          <span className="text-xs text-slate-500">
                            {format(new Date(chat.lastMessageTime), 'HH:mm')}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <p className="text-sm text-slate-500 truncate flex-1">
                          {chat.lastMessage}
                        </p>
                        {chat.unreadCount > 0 && (
                          <span className="w-5 h-5 bg-blue-600 text-white text-xs font-bold rounded-full flex items-center justify-center">
                            {chat.unreadCount}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  // Active chat view
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <div className="bg-white px-5 pt-12 pb-4 border-b border-slate-100 shrink-0">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleBack}
            className="rounded-xl"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          
          <div className="flex items-center gap-3 flex-1">
            <Avatar className="w-10 h-10">
              <AvatarImage src={activeChat.driver.photo} />
              <AvatarFallback className="bg-blue-100 text-blue-600 font-bold">
                {activeChat.driver.name.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div>
              <h2 className="font-semibold text-slate-900">{activeChat.driver.name}</h2>
              <p className="text-xs text-slate-500">
                {activeChat.driver.vehicle_model} • {activeChat.driver.vehicle_plate}
              </p>
            </div>
          </div>

          <Button
            size="icon"
            onClick={handleCallDriver}
            className="rounded-xl bg-emerald-600 hover:bg-emerald-700"
          >
            <Phone className="w-4 h-4 text-white" />
          </Button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-5 space-y-4">
        <AnimatePresence mode="popLayout">
          {activeChat.messages.map((msg, index) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ delay: index * 0.05 }}
              className={cn(
                "flex",
                msg.sender === 'user' ? 'justify-end' : 'justify-start'
              )}
            >
              <div className={cn(
                "max-w-[80%] rounded-2xl px-4 py-3",
                msg.sender === 'user'
                  ? 'bg-blue-600 text-white rounded-br-md'
                  : 'bg-white text-slate-900 rounded-bl-md shadow-sm border border-slate-100'
              )}>
                <p className="text-sm">{msg.text}</p>
                <div className={cn(
                  "flex items-center justify-end gap-1 mt-1",
                  msg.sender === 'user' ? 'text-blue-200' : 'text-slate-400'
                )}>
                  <span className="text-xs">
                    {format(new Date(msg.timestamp), 'HH:mm')}
                  </span>
                  {msg.sender === 'user' && (
                    <CheckCheck className={cn(
                      "w-3 h-3",
                      msg.read ? 'text-blue-200' : 'text-blue-300'
                    )} />
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Replies */}
      <div className="px-5 py-2 bg-white border-t border-slate-100 overflow-x-auto">
        <div className="flex gap-2">
          {generateQuickReplies().map((reply) => (
            <button
              key={reply}
              onClick={() => handleQuickReply(reply)}
              className="px-4 py-2 bg-slate-100 text-slate-700 text-sm rounded-full whitespace-nowrap hover:bg-slate-200 transition-colors"
            >
              {reply}
            </button>
          ))}
        </div>
      </div>

      {/* Input */}
      <div className="p-5 bg-white border-t border-slate-100 shrink-0">
        <div className="flex gap-3">
          <Input
            ref={inputRef}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Digite sua mensagem..."
            className="h-12 rounded-xl"
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
          />
          <Button
            onClick={handleSendMessage}
            disabled={!message.trim()}
            className="h-12 w-12 rounded-xl bg-blue-600 hover:bg-blue-700"
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
