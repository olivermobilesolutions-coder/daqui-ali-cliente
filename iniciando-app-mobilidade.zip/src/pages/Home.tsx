import { Bike, Car, Package, Truck, Bus, Bell } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useUser, useNotifications } from '@/hooks/useStore';
import ServiceCard from '@/components/home/ServiceCard';
import WalletCard from '@/components/home/WalletCard';
import { motion } from 'framer-motion';

export default function Home() {
  const navigate = useNavigate();
  const { user, loading } = useUser();
  const { unreadCount } = useNotifications();

  const services = [
    {
      icon: Bike,
      title: 'Moto Táxi',
      description: 'Rápido e econômico',
      page: 'RideRequest?type=moto',
      color: 'bg-blue-600'
    },
    {
      icon: Car,
      title: 'Carro',
      description: 'Conforto e segurança',
      page: 'RideRequest?type=car',
      color: 'bg-indigo-600'
    },
    {
      icon: Package,
      title: 'Entregas',
      description: 'Delivery e documentos',
      page: 'DeliveryRequest',
      color: 'bg-emerald-600'
    },
    {
      icon: Truck,
      title: 'Fretes',
      description: 'Mudanças e cargas',
      page: 'FreightRequest?type=freight',
      color: 'bg-orange-500'
    },
    {
      icon: Bus,
      title: 'Vans e Ônibus',
      description: 'Excursões e grupos',
      page: 'FreightRequest?type=excursion',
      color: 'bg-purple-600'
    }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white px-5 pt-12 pb-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">
              Daqui Ali
            </h1>
            <p className="text-slate-500 text-sm">
              Olá, {user?.full_name?.split(' ')[0] || 'Usuário'}! Para onde vamos?
            </p>
          </div>
          <button 
            onClick={() => navigate('/Notifications')}
            className="relative w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center hover:bg-slate-200 transition-colors"
          >
            <Bell className="w-5 h-5 text-slate-600" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-[10px] text-white font-bold flex items-center justify-center">
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </button>
        </div>

        {/* Wallet Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <WalletCard 
            balance={user?.wallet_balance || 0} 
            userName={user?.full_name?.split(' ')[0]} 
          />
        </motion.div>
      </div>

      {/* Services Grid */}
      <div className="px-5 py-6">
        <h2 className="text-lg font-semibold text-slate-900 mb-4">
          Nossos Serviços
        </h2>
        
        <div className="grid grid-cols-2 gap-4">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
            >
              <ServiceCard
                {...service}
                delay={index * 100}
              />
            </motion.div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-5 pb-8 space-y-4">
        {/* Active Ride Banner */}
        <ActiveRideBanner />
        
        {/* Referral Banner */}
        <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-2xl p-5 flex items-center justify-between">
          <div>
            <p className="text-white font-semibold mb-1">
              Convide amigos
            </p>
            <p className="text-slate-400 text-sm">
              Ganhe R$ 5 por indicação
            </p>
          </div>
          <button 
            onClick={() => {
              if (navigator.share) {
                navigator.share({
                  title: 'Daqui Ali',
                  text: `Use meu código ${user?.referral_code || 'DAQUIALI'} e ganhe R$ 5 na primeira corrida!`,
                  url: 'https://daquiali.com',
                });
              }
            }}
            className="bg-white text-slate-900 font-semibold px-4 py-2 rounded-xl text-sm hover:bg-slate-100 transition-colors"
          >
            Convidar
          </button>
        </div>
      </div>
    </div>
  );
}

// Component to show active ride
function ActiveRideBanner() {
  const navigate = useNavigate();
  const { rides } = useRidesSimple();
  
  const activeRide = rides.find((r: storage.Ride) => 
    ['pending', 'searching', 'accepted', 'driver_arriving', 'arrived', 'in_progress'].includes(r.status)
  );

  if (!activeRide) return null;

  const statusLabels: Record<string, string> = {
    pending: 'Buscando motorista...',
    searching: 'Buscando motorista...',
    accepted: 'Motorista a caminho',
    driver_arriving: 'Motorista chegando',
    arrived: 'Motorista chegou!',
    in_progress: 'Em viagem',
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-4"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
            {activeRide.type === 'moto' ? (
              <Bike className="w-5 h-5 text-white" />
            ) : (
              <Car className="w-5 h-5 text-white" />
            )}
          </div>
          <div>
            <p className="text-white font-semibold">Corrida em andamento</p>
            <p className="text-blue-200 text-sm">{statusLabels[activeRide.status]}</p>
          </div>
        </div>
        <button
          onClick={() => navigate(`/RideTracking?id=${activeRide.id}`)}
          className="bg-white text-blue-600 font-semibold px-4 py-2 rounded-xl text-sm"
        >
          Ver
        </button>
      </div>
    </motion.div>
  );
}

// Simple hook to get rides without full functionality
import { useState, useEffect } from 'react';
import * as storage from '@/lib/storage';

function useRidesSimple() {
  const [rides, setRides] = useState<storage.Ride[]>([]);
  
  useEffect(() => {
    const data = storage.getRides();
    setRides(data);
    
    // Poll for updates
    const interval = setInterval(() => {
      const updated = storage.getRides();
      setRides(updated);
    }, 2000);
    
    return () => clearInterval(interval);
  }, []);
  
  return { rides };
}
