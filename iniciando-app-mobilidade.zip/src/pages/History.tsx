import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import * as storage from '@/lib/storage';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Bike, Car, Package, Truck, Bus, Clock, MapPin, ChevronRight, RefreshCw, Star, MessageCircle, RotateCcw } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface HistoryItem {
  id: string;
  itemType: 'ride' | 'delivery' | 'freight';
  type?: string;
  category?: string;
  status: string;
  created_at: string;
  completed_at?: string;
  price?: number;
  final_price?: number;
  origin?: { address: string };
  destination?: { address: string };
  driver?: storage.Driver;
  rating?: number;
}

export default function History() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('all');
  const [loading, setLoading] = useState(true);
  const [allItems, setAllItems] = useState<HistoryItem[]>([]);
  const [selectedItem, setSelectedItem] = useState<HistoryItem | null>(null);
  const [showDetails, setShowDetails] = useState(false);

  const loadData = () => {
    setLoading(true);
    
    const rides = storage.getRides().map(r => ({ 
      ...r, 
      itemType: 'ride' as const,
      created_at: r.created_at 
    }));
    const deliveries = storage.getDeliveries().map(d => ({ 
      ...d, 
      itemType: 'delivery' as const,
      created_at: d.created_at 
    }));
    const freights = storage.getFreights().map(f => ({ 
      ...f, 
      itemType: 'freight' as const,
      created_at: f.created_at 
    }));

    const items = [...rides, ...deliveries, ...freights]
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    
    setAllItems(items);
    setLoading(false);
  };

  useEffect(() => {
    loadData();
    // Auto-refresh every 5 seconds
    const interval = setInterval(loadData, 5000);
    return () => clearInterval(interval);
  }, []);

  const filteredItems = activeTab === 'all' 
    ? allItems 
    : allItems.filter(item => item.itemType === activeTab);

  const getIcon = (item: HistoryItem) => {
    if (item.itemType === 'delivery') return Package;
    if (item.itemType === 'freight') return item.category === 'excursion' ? Bus : Truck;
    return item.type === 'moto' ? Bike : Car;
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      pending: 'bg-amber-100 text-amber-700',
      searching: 'bg-amber-100 text-amber-700',
      accepted: 'bg-blue-100 text-blue-700',
      driver_arriving: 'bg-blue-100 text-blue-700',
      arrived: 'bg-blue-100 text-blue-700',
      in_progress: 'bg-blue-100 text-blue-700',
      in_transit: 'bg-blue-100 text-blue-700',
      picking_up: 'bg-blue-100 text-blue-700',
      completed: 'bg-emerald-100 text-emerald-700',
      delivered: 'bg-emerald-100 text-emerald-700',
      cancelled: 'bg-red-100 text-red-700',
      awaiting_quote: 'bg-purple-100 text-purple-700',
      proposal_sent: 'bg-indigo-100 text-indigo-700',
    };
    return colors[status] || 'bg-slate-100 text-slate-700';
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      pending: 'Pendente',
      searching: 'Buscando...',
      accepted: 'Aceito',
      driver_arriving: 'A caminho',
      arrived: 'Chegou',
      in_progress: 'Em andamento',
      in_transit: 'Em trânsito',
      completed: 'Finalizado',
      delivered: 'Entregue',
      cancelled: 'Cancelado',
      awaiting_quote: 'Aguardando orçamento',
      proposal_sent: 'Proposta enviada',
      picking_up: 'Coletando',
    };
    return labels[status] || status;
  };

  const getItemLabel = (item: HistoryItem) => {
    if (item.itemType === 'delivery') return 'Entrega';
    if (item.itemType === 'freight') {
      if (item.category === 'excursion') return 'Excursão';
      if (item.category === 'moving') return 'Mudança';
      return 'Frete';
    }
    return item.type === 'moto' ? 'Moto Táxi' : 'Carro';
  };

  const handleItemClick = (item: HistoryItem) => {
    // If active, navigate to tracking
    if (!['completed', 'delivered', 'cancelled'].includes(item.status)) {
      if (item.itemType === 'ride') {
        navigate(`/RideTracking?id=${item.id}`);
      } else if (item.itemType === 'delivery') {
        navigate(`/DeliveryTracking?id=${item.id}`);
      }
    } else {
      // Show details modal
      setSelectedItem(item);
      setShowDetails(true);
    }
  };

  const handleRepeatRide = (item: HistoryItem) => {
    if (item.itemType === 'ride') {
      navigate(`/RideRequest?type=${item.type}`);
    } else if (item.itemType === 'delivery') {
      navigate('/DeliveryRequest');
    } else {
      navigate(`/FreightRequest?type=${item.category}`);
    }
    setShowDetails(false);
  };

  const handleChatWithDriver = (item: HistoryItem) => {
    const chatId = item.itemType === 'ride' ? `ride-${item.id}` : `delivery-${item.id}`;
    navigate(`/Chat?id=${chatId}`);
    setShowDetails(false);
  };

  // Statistics
  const completedRides = allItems.filter(i => ['completed', 'delivered'].includes(i.status)).length;
  const totalSpent = allItems
    .filter(i => ['completed', 'delivered'].includes(i.status))
    .reduce((sum, i) => sum + (i.final_price || i.price || 0), 0);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white px-5 pt-12 pb-4 border-b border-slate-100">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold text-slate-900">Histórico</h1>
          <Button
            variant="ghost"
            size="icon"
            onClick={loadData}
            className="rounded-xl"
          >
            <RefreshCw className="w-5 h-5" />
          </Button>
        </div>

        {/* Stats */}
        {allItems.length > 0 && (
          <div className="flex gap-3 mb-4">
            <div className="flex-1 bg-blue-50 rounded-xl p-3">
              <p className="text-xs text-blue-600 font-medium">Corridas</p>
              <p className="text-lg font-bold text-blue-900">{completedRides}</p>
            </div>
            <div className="flex-1 bg-emerald-50 rounded-xl p-3">
              <p className="text-xs text-emerald-600 font-medium">Total gasto</p>
              <p className="text-lg font-bold text-emerald-900">
                R$ {totalSpent.toFixed(2).replace('.', ',')}
              </p>
            </div>
          </div>
        )}
        
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-slate-100 p-1 rounded-xl w-full">
            <TabsTrigger 
              value="all" 
              className="flex-1 rounded-lg data-[state=active]:bg-white text-xs"
            >
              Todos ({allItems.length})
            </TabsTrigger>
            <TabsTrigger 
              value="ride" 
              className="flex-1 rounded-lg data-[state=active]:bg-white text-xs"
            >
              Corridas
            </TabsTrigger>
            <TabsTrigger 
              value="delivery" 
              className="flex-1 rounded-lg data-[state=active]:bg-white text-xs"
            >
              Entregas
            </TabsTrigger>
            <TabsTrigger 
              value="freight" 
              className="flex-1 rounded-lg data-[state=active]:bg-white text-xs"
            >
              Fretes
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Content */}
      <div className="p-5">
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-white rounded-2xl p-4 animate-pulse">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-slate-200 rounded-xl" />
                  <div className="flex-1">
                    <div className="h-4 bg-slate-200 rounded w-1/2 mb-2" />
                    <div className="h-3 bg-slate-200 rounded w-1/3" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : filteredItems.length === 0 ? (
          <div className="text-center py-16">
            <Clock className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-500 mb-2">Nenhum registro encontrado</p>
            <p className="text-sm text-slate-400 mb-4">
              Solicite uma corrida ou entrega para começar!
            </p>
            <Button onClick={() => navigate('/')}>
              Solicitar agora
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredItems.map((item, index) => {
              const Icon = getIcon(item);
              const isActive = !['completed', 'delivered', 'cancelled'].includes(item.status);
              
              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => handleItemClick(item)}
                  className={cn(
                    "bg-white rounded-2xl p-4 shadow-sm border cursor-pointer hover:shadow-md transition-shadow",
                    isActive ? "border-blue-200 ring-2 ring-blue-100" : "border-slate-100"
                  )}
                >
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-12 h-12 rounded-xl flex items-center justify-center",
                      item.itemType === 'delivery' ? 'bg-emerald-100' :
                      item.itemType === 'freight' ? 'bg-orange-100' :
                      item.type === 'moto' ? 'bg-blue-100' : 'bg-indigo-100'
                    )}>
                      <Icon className={cn(
                        "w-6 h-6",
                        item.itemType === 'delivery' ? 'text-emerald-600' :
                        item.itemType === 'freight' ? 'text-orange-600' :
                        item.type === 'moto' ? 'text-blue-600' : 'text-indigo-600'
                      )} />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-semibold text-slate-900 truncate">
                          {getItemLabel(item)}
                        </p>
                        <Badge className={cn("text-xs", getStatusColor(item.status))}>
                          {getStatusLabel(item.status)}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-3 text-sm text-slate-500">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {format(new Date(item.created_at), "dd MMM, HH:mm", { locale: ptBR })}
                        </span>
                        {(item.price || item.final_price) && (
                          <>
                            <span>•</span>
                            <span className="font-medium text-slate-900">
                              R$ {(item.final_price || item.price || 0).toFixed(2).replace('.', ',')}
                            </span>
                          </>
                        )}
                      </div>

                      {/* Driver info for active rides */}
                      {isActive && item.driver && (
                        <div className="flex items-center gap-2 mt-2">
                          <div className="w-6 h-6 bg-slate-200 rounded-full flex items-center justify-center text-xs font-bold text-slate-600">
                            {item.driver.name.charAt(0)}
                          </div>
                          <span className="text-xs text-slate-500">{item.driver.name}</span>
                        </div>
                      )}
                    </div>

                    <ChevronRight className="w-5 h-5 text-slate-400" />
                  </div>

                  {/* Route preview */}
                  {(item.origin?.address || item.destination?.address) && (
                    <div className="mt-3 pt-3 border-t border-slate-100">
                      <div className="flex items-start gap-2 text-sm">
                        <MapPin className="w-4 h-4 text-blue-500 mt-0.5 shrink-0" />
                        <p className="text-slate-600 truncate">
                          {item.origin?.address || 'Origem'} → {item.destination?.address || 'Destino'}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Rating display for completed */}
                  {item.status === 'completed' && item.rating && (
                    <div className="mt-3 pt-3 border-t border-slate-100 flex items-center gap-1">
                      <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                      <span className="text-sm font-medium text-amber-700">
                        Você avaliou: {item.rating} estrelas
                      </span>
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Details Modal */}
      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Detalhes</DialogTitle>
          </DialogHeader>

          {selectedItem && (
            <div className="space-y-4">
              {/* Status */}
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Status</span>
                <Badge className={getStatusColor(selectedItem.status)}>
                  {getStatusLabel(selectedItem.status)}
                </Badge>
              </div>

              {/* Date */}
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Data</span>
                <span className="font-medium">
                  {format(new Date(selectedItem.created_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                </span>
              </div>

              {/* Price */}
              {(selectedItem.price || selectedItem.final_price) && (
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Valor</span>
                  <span className="font-bold text-lg">
                    R$ {(selectedItem.final_price || selectedItem.price || 0).toFixed(2).replace('.', ',')}
                  </span>
                </div>
              )}

              {/* Route */}
              {(selectedItem.origin?.address || selectedItem.destination?.address) && (
                <div className="bg-slate-50 rounded-xl p-4 space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-3 h-3 rounded-full bg-blue-600 mt-1" />
                    <div>
                      <p className="text-xs text-slate-500">Origem</p>
                      <p className="font-medium text-slate-900">{selectedItem.origin?.address || 'N/A'}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-3 h-3 rounded-full bg-emerald-600 mt-1" />
                    <div>
                      <p className="text-xs text-slate-500">Destino</p>
                      <p className="font-medium text-slate-900">{selectedItem.destination?.address || 'N/A'}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Driver */}
              {selectedItem.driver && (
                <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-bold">
                    {selectedItem.driver.name.charAt(0)}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{selectedItem.driver.name}</p>
                    <div className="flex items-center gap-1 text-sm text-slate-500">
                      <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                      <span>{selectedItem.driver.rating}</span>
                      <span>•</span>
                      <span>{selectedItem.driver.vehicle_model}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-3 pt-2">
                {selectedItem.driver && (
                  <Button
                    variant="outline"
                    onClick={() => handleChatWithDriver(selectedItem)}
                    className="flex-1 h-12 rounded-xl"
                  >
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Mensagem
                  </Button>
                )}
                <Button
                  onClick={() => handleRepeatRide(selectedItem)}
                  className="flex-1 h-12 rounded-xl"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Repetir
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
