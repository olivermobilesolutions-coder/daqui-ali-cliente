import { useState } from 'react';
import { useUser, useTransactions } from '@/hooks/useStore';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { 
  Wallet, Plus, ArrowDownLeft, ArrowUpRight, Gift, 
  QrCode, Copy, Check
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

export default function WalletPage() {
  const { user, addBalance, refreshUser } = useUser();
  const { transactions, loading: loadingTransactions, refresh: refreshTransactions } = useTransactions();
  
  const [showAddFunds, setShowAddFunds] = useState(false);
  const [amount, setAmount] = useState('');
  const [pixCode, setPixCode] = useState('');
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleAddFunds = async () => {
    if (!amount || parseFloat(amount) <= 0) return;
    
    setLoading(true);
    
    // Simulate PIX generation
    setTimeout(() => {
      setPixCode('00020126580014BR.GOV.BCB.PIX0136daquiali@pix.com.br5204000053039865802BR5925DAQUI ALI MOBILIDADE6009SAO PAULO62070503***6304ABCD');
      setLoading(false);
    }, 1000);
  };

  const handleConfirmDeposit = () => {
    const depositAmount = parseFloat(amount);
    if (depositAmount > 0) {
      addBalance(depositAmount);
      refreshTransactions();
      refreshUser();
      setPixCode('');
      setAmount('');
      setShowAddFunds(false);
    }
  };

  const copyPixCode = () => {
    navigator.clipboard.writeText(pixCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getTransactionIcon = (type: string) => {
    const icons: Record<string, typeof ArrowDownLeft> = {
      deposit: ArrowDownLeft,
      payment: ArrowUpRight,
      tip: Gift,
      refund: ArrowDownLeft,
      referral_bonus: Gift,
      cancellation_fee: ArrowUpRight,
    };
    return icons[type] || ArrowUpRight;
  };

  const getTransactionColor = (type: string) => {
    const colors: Record<string, string> = {
      deposit: 'text-emerald-600 bg-emerald-100',
      payment: 'text-red-600 bg-red-100',
      tip: 'text-amber-600 bg-amber-100',
      refund: 'text-blue-600 bg-blue-100',
      referral_bonus: 'text-purple-600 bg-purple-100',
      cancellation_fee: 'text-red-600 bg-red-100',
    };
    return colors[type] || 'text-slate-600 bg-slate-100';
  };

  const getTransactionLabel = (type: string) => {
    const labels: Record<string, string> = {
      deposit: 'Depósito',
      payment: 'Pagamento',
      tip: 'Gorjeta',
      refund: 'Reembolso',
      referral_bonus: 'Bônus indicação',
      cancellation_fee: 'Taxa cancelamento',
    };
    return labels[type] || type;
  };

  const quickAmounts = [10, 20, 50, 100];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white px-5 pt-12 pb-6">
        <h1 className="text-2xl font-bold text-slate-900 mb-6">Carteira</h1>

        {/* Balance Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-600 to-indigo-700 p-6 text-white shadow-xl"
        >
          <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full -translate-y-24 translate-x-24" />
          
          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                <Wallet className="w-5 h-5" />
              </div>
              <span className="font-medium text-blue-100">Saldo disponível</span>
            </div>
            
            <p className="text-4xl font-bold tracking-tight mb-6">
              R$ {(user?.wallet_balance || 0).toFixed(2).replace('.', ',')}
            </p>
            
            <Button
              onClick={() => setShowAddFunds(true)}
              className="w-full h-12 bg-white text-blue-600 hover:bg-blue-50 font-semibold rounded-xl"
            >
              <Plus className="w-5 h-5 mr-2" />
              Adicionar saldo
            </Button>
          </div>
        </motion.div>
      </div>

      {/* Referral Banner */}
      <div className="px-5 py-4">
        <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-2xl p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
              <Gift className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-white font-semibold">Convide amigos</p>
              <p className="text-purple-200 text-sm">Ganhe R$ 5 por indicação</p>
            </div>
          </div>
          <Button
            variant="secondary"
            size="sm"
            className="rounded-xl bg-white text-purple-600 hover:bg-purple-50"
            onClick={() => {
              if (navigator.share) {
                navigator.share({
                  title: 'Daqui Ali',
                  text: `Use meu código ${user?.referral_code || 'DAQUIALI'} e ganhe R$ 5!`,
                });
              }
            }}
          >
            Convidar
          </Button>
        </div>
      </div>

      {/* Transactions */}
      <div className="px-5 pb-8">
        <h2 className="font-semibold text-slate-900 mb-4">Movimentações</h2>
        
        {loadingTransactions ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-white rounded-xl p-4 animate-pulse">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-slate-200 rounded-xl" />
                  <div className="flex-1">
                    <div className="h-4 bg-slate-200 rounded w-1/3 mb-2" />
                    <div className="h-3 bg-slate-200 rounded w-1/4" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : transactions.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl">
            <Wallet className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-500">Nenhuma movimentação ainda</p>
            <p className="text-sm text-slate-400 mt-1">Adicione saldo para começar!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {transactions.map((tx, index) => {
              const Icon = getTransactionIcon(tx.type);
              const isPositive = ['deposit', 'refund', 'referral_bonus'].includes(tx.type);
              
              return (
                <motion.div
                  key={tx.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-white rounded-xl p-4 flex items-center gap-3"
                >
                  <div className={cn(
                    "w-10 h-10 rounded-xl flex items-center justify-center",
                    getTransactionColor(tx.type)
                  )}>
                    <Icon className="w-5 h-5" />
                  </div>
                  
                  <div className="flex-1">
                    <p className="font-medium text-slate-900">
                      {getTransactionLabel(tx.type)}
                    </p>
                    <p className="text-xs text-slate-500">
                      {format(new Date(tx.created_at), "dd MMM, HH:mm", { locale: ptBR })}
                    </p>
                  </div>
                  
                  <p className={cn(
                    "font-semibold",
                    isPositive ? "text-emerald-600" : "text-red-600"
                  )}>
                    {isPositive ? '+' : ''} R$ {Math.abs(tx.amount).toFixed(2).replace('.', ',')}
                  </p>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Add Funds Modal */}
      <Dialog open={showAddFunds} onOpenChange={setShowAddFunds}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Adicionar saldo</DialogTitle>
          </DialogHeader>

          {!pixCode ? (
            <div className="space-y-6">
              <div>
                <label className="text-sm text-slate-500 mb-2 block">Valor</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 font-medium text-lg">
                    R$
                  </span>
                  <Input
                    type="number"
                    placeholder="0,00"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="h-14 rounded-xl pl-12 text-2xl font-semibold"
                  />
                </div>
                
                <div className="flex gap-2 mt-3">
                  {quickAmounts.map((val) => (
                    <button
                      key={val}
                      onClick={() => setAmount(String(val))}
                      className={cn(
                        "flex-1 py-2 rounded-lg text-sm font-medium transition-all",
                        amount === String(val)
                          ? "bg-blue-600 text-white"
                          : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                      )}
                    >
                      R$ {val}
                    </button>
                  ))}
                </div>
              </div>

              <Button
                onClick={handleAddFunds}
                disabled={!amount || loading}
                className="w-full h-12 rounded-xl bg-blue-600 hover:bg-blue-700"
              >
                {loading ? 'Gerando PIX...' : 'Gerar PIX'}
              </Button>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <QrCode className="w-8 h-8 text-emerald-600" />
                </div>
                <p className="text-lg font-semibold">PIX gerado!</p>
                <p className="text-sm text-slate-500">Copie o código e pague no seu banco</p>
              </div>

              <div className="bg-slate-100 rounded-xl p-4">
                <p className="text-xs text-slate-500 mb-2">Código PIX Copia e Cola</p>
                <p className="text-sm font-mono break-all">{pixCode.slice(0, 60)}...</p>
              </div>

              <Button
                onClick={copyPixCode}
                variant="outline"
                className="w-full h-12 rounded-xl"
              >
                {copied ? (
                  <>
                    <Check className="w-5 h-5 mr-2" />
                    Copiado!
                  </>
                ) : (
                  <>
                    <Copy className="w-5 h-5 mr-2" />
                    Copiar código PIX
                  </>
                )}
              </Button>

              <Button
                onClick={handleConfirmDeposit}
                className="w-full h-12 rounded-xl bg-emerald-600 hover:bg-emerald-700"
              >
                Já paguei - Confirmar depósito
              </Button>

              <Button
                variant="ghost"
                onClick={() => {
                  setPixCode('');
                  setAmount('');
                }}
                className="w-full"
              >
                Cancelar
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
