import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useUser, usePriceCalculation, useAddresses } from '@/hooks/useStore';
import * as storage from '@/lib/storage';
import { ArrowLeft, Bike, Car, Home, Briefcase, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import LocationInput from '@/components/ride/LocationInput';
import MotoFilters from '@/components/ride/MotoFilters';
import CarFilters from '@/components/ride/CarFilters';
import PaymentSelector from '@/components/ride/PaymentSelector';
import PriceEstimate from '@/components/ride/PriceEstimate';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';

interface Location {
  address: string;
  lat?: number;
  lng?: number;
}

export default function RideRequest() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const rideType = (searchParams.get('type') || 'moto') as 'moto' | 'car';

  const { user } = useUser();
  const { addresses } = useAddresses();
  const { calculateRidePrice, estimateDistance, estimateTime } = usePriceCalculation();
  
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  
  const [origin, setOrigin] = useState<Location>({ address: '' });
  const [destination, setDestination] = useState<Location>({ address: '' });
  const [stops, setStops] = useState<Location[]>([]);
  const [preferences, setPreferences] = useState({
    gender: 'any',
    moto_quantity: 1,
    car_category: 'common',
    ac: true,
    music: false,
    silence: false,
    specific_driver_id: ''
  });
  const [paymentMethod, setPaymentMethod] = useState('wallet');
  const [estimatedPrice, setEstimatedPrice] = useState<number | null>(null);
  const [estimatedDistance, setEstimatedDistance] = useState(0);
  const [estimatedTimeMinutes, setEstimatedTimeMinutes] = useState(0);

  // Calculate price when locations change
  useEffect(() => {
    if (origin.address && destination.address) {
      const distance = estimateDistance(origin.address, destination.address);
      const price = calculateRidePrice(rideType, distance, stops.length, preferences);
      const time = estimateTime(distance, rideType);
      
      setEstimatedDistance(distance);
      setEstimatedPrice(price);
      setEstimatedTimeMinutes(time);
    }
  }, [origin, destination, stops, preferences, rideType, calculateRidePrice, estimateDistance, estimateTime]);

  const handleUseCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setOrigin({
            address: 'Minha localização atual',
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        () => {
          // Fallback if geolocation fails
          setOrigin({
            address: 'Minha localização atual',
          });
        }
      );
    }
  };

  const handleAddStop = () => {
    if (stops.length < 10) {
      setStops([...stops, { address: '' }]);
    }
  };

  const handleRemoveStop = (index: number) => {
    setStops(stops.filter((_, i) => i !== index));
  };

  const handleStopChange = (index: number, value: Location) => {
    const newStops = [...stops];
    newStops[index] = value;
    setStops(newStops);
  };

  const handleSelectSavedAddress = (address: storage.SavedAddress, type: 'origin' | 'destination') => {
    const location: Location = {
      address: address.address,
      lat: address.lat,
      lng: address.lng,
    };
    if (type === 'origin') {
      setOrigin(location);
    } else {
      setDestination(location);
    }
  };

  const handleConfirmRide = async () => {
    if (!estimatedPrice) return;
    
    setLoading(true);
    
    try {
      // Check wallet balance if paying with wallet
      if (paymentMethod === 'wallet' && (user?.wallet_balance || 0) < estimatedPrice) {
        alert('Saldo insuficiente na carteira. Por favor, adicione saldo ou escolha outra forma de pagamento.');
        setLoading(false);
        return;
      }

      // Create ride
      const ride = storage.createRide({
        type: rideType,
        status: 'pending',
        origin,
        destination,
        stops,
        price: estimatedPrice,
        price_type: 'dynamic',
        payment_method: paymentMethod,
        preferences,
        estimated_time: estimatedTimeMinutes,
        estimated_distance: estimatedDistance,
      });

      // If paying with wallet, deduct balance
      if (paymentMethod === 'wallet') {
        storage.deductBalance(estimatedPrice);
        storage.createTransaction({
          type: 'payment',
          amount: -estimatedPrice,
          description: `Corrida de ${rideType === 'moto' ? 'Moto' : 'Carro'}`,
          reference_id: ride.id,
          reference_type: 'ride',
        });
      }
      
      // Navigate to tracking
      navigate(`/RideTracking?id=${ride.id}`);
    } catch (error) {
      console.error('Erro ao criar corrida:', error);
      alert('Erro ao criar corrida. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const canProceed = () => {
    if (step === 1) return origin.address && destination.address;
    if (step === 2) return true;
    if (step === 3) return paymentMethod;
    return false;
  };

  // Get saved addresses
  const homeAddress = addresses.find(a => a.type === 'home');
  const workAddress = addresses.find(a => a.type === 'work');

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white px-5 pt-12 pb-4 border-b border-slate-100">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
            className="rounded-xl"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex items-center gap-3">
            {rideType === 'moto' ? (
              <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
                <Bike className="w-5 h-5 text-blue-600" />
              </div>
            ) : (
              <div className="w-10 h-10 bg-indigo-100 rounded-xl flex items-center justify-center">
                <Car className="w-5 h-5 text-indigo-600" />
              </div>
            )}
            <div>
              <h1 className="font-semibold text-slate-900">
                {rideType === 'moto' ? 'Moto Táxi' : 'Carro'}
              </h1>
              <p className="text-xs text-slate-500">
                Passo {step} de 3
              </p>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="flex gap-2 mt-4">
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              className={`h-1 flex-1 rounded-full transition-colors ${
                s <= step ? 'bg-blue-600' : 'bg-slate-200'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="p-5 space-y-4">
        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              {/* Saved Addresses Quick Select */}
              {(homeAddress || workAddress) && (
                <div className="flex gap-3">
                  {homeAddress && (
                    <button
                      onClick={() => handleSelectSavedAddress(homeAddress, 'destination')}
                      className="flex-1 flex items-center gap-3 p-3 bg-white rounded-xl border border-slate-200 hover:border-blue-300 transition-colors"
                    >
                      <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Home className="w-4 h-4 text-blue-600" />
                      </div>
                      <div className="text-left">
                        <p className="text-sm font-medium text-slate-900">Casa</p>
                        <p className="text-xs text-slate-500 truncate">{homeAddress.address.slice(0, 20)}...</p>
                      </div>
                    </button>
                  )}
                  {workAddress && (
                    <button
                      onClick={() => handleSelectSavedAddress(workAddress, 'destination')}
                      className="flex-1 flex items-center gap-3 p-3 bg-white rounded-xl border border-slate-200 hover:border-blue-300 transition-colors"
                    >
                      <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                        <Briefcase className="w-4 h-4 text-purple-600" />
                      </div>
                      <div className="text-left">
                        <p className="text-sm font-medium text-slate-900">Trabalho</p>
                        <p className="text-xs text-slate-500 truncate">{workAddress.address.slice(0, 20)}...</p>
                      </div>
                    </button>
                  )}
                </div>
              )}

              <LocationInput
                origin={origin}
                destination={destination}
                stops={stops}
                onOriginChange={setOrigin}
                onDestinationChange={setDestination}
                onAddStop={handleAddStop}
                onRemoveStop={handleRemoveStop}
                onStopChange={handleStopChange}
                onUseCurrentLocation={handleUseCurrentLocation}
              />

              {/* Distance preview */}
              {origin.address && destination.address && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-blue-50 rounded-xl p-4 flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <MapPin className="w-5 h-5 text-blue-600" />
                    <div>
                      <p className="text-sm font-medium text-blue-900">Distância estimada</p>
                      <p className="text-xs text-blue-600">{estimatedDistance.toFixed(1)} km • ~{estimatedTimeMinutes} min</p>
                    </div>
                  </div>
                  <p className="text-lg font-bold text-blue-600">
                    R$ {estimatedPrice?.toFixed(2).replace('.', ',')}
                  </p>
                </motion.div>
              )}
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              {rideType === 'moto' ? (
                <MotoFilters
                  preferences={preferences}
                  onPreferencesChange={setPreferences}
                />
              ) : (
                <CarFilters
                  preferences={preferences}
                  onPreferencesChange={setPreferences}
                />
              )}
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <PaymentSelector
                selected={paymentMethod}
                onSelect={setPaymentMethod}
                walletBalance={user?.wallet_balance || 0}
              />
              
              {estimatedPrice && (
                <PriceEstimate
                  price={estimatedPrice}
                  estimatedTime={estimatedTimeMinutes}
                  distance={estimatedDistance}
                  onConfirm={handleConfirmRide}
                  loading={loading}
                  type={rideType}
                />
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Bottom Actions */}
      {step < 3 && (
        <div className="fixed bottom-0 left-0 right-0 p-5 bg-white border-t border-slate-100">
          <div className="flex gap-3">
            {step > 1 && (
              <Button
                variant="outline"
                onClick={() => setStep(step - 1)}
                className="h-14 px-6 rounded-xl"
              >
                Voltar
              </Button>
            )}
            <Button
              onClick={() => setStep(step + 1)}
              disabled={!canProceed()}
              className={cn(
                "flex-1 h-14 rounded-xl text-white font-semibold",
                rideType === 'moto' ? "bg-blue-600 hover:bg-blue-700" : "bg-indigo-600 hover:bg-indigo-700"
              )}
            >
              Continuar
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
