import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import * as storage from '@/lib/storage';
import { ArrowLeft, Package, Phone, MessageCircle, Star, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

export default function DeliveryTracking() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const deliveryId = searchParams.get('id') || '';

  const [delivery, setDelivery] = useState<storage.Delivery | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDelivery();
    
    // Simulate status progression
    const interval = setInterval(() => {
      const current = storage.getDeliveryById(deliveryId);
      if (current) {
        const statusOrder: storage.Delivery['status'][] = ['pending', 'accepted', 'picking_up', 'in_transit', 'delivered'];
        const currentIndex = statusOrder.indexOf(current.status);
        
        if (currentIndex >= 0 && currentIndex < statusOrder.length - 1) {
          const nextStatus = statusOrder[currentIndex + 1];
          const updated = storage.updateDelivery(deliveryId, { 
            status: nextStatus,
            ...(nextStatus === 'delivered' ? { completed_at: new Date().toISOString() } : {})
          });
          if (updated) setDelivery(updated);
        }
        
        // Assign driver when accepted
        if (current.status === 'pending' && !current.driver) {
          const driver = storage.getRandomDriver('moto');
          const updated = storage.updateDelivery(deliveryId, { 
            status: 'accepted',
            driver 
          });
          if (updated) setDelivery(updated);
        }
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [deliveryId]);

  const loadDelivery = () => {
    const data = storage.getDeliveryById(deliveryId);
    setDelivery(data || null);
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-emerald-200 border-t-emerald-600 rounded-full animate-spin" />
      </div>
    );
  }

  if (!delivery) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6">
        <p className="text-slate-600 mb-4">Entrega não encontrada</p>
        <Button onClick={() => navigate('/')}>Voltar ao início</Button>
      </div>
    );
  }

  const isCompleted = delivery.status === 'delivered';
  const statusSteps = [
    { status: 'pending', label: 'Aguardando', icon: '⏳' },
    { status: 'accepted', label: 'Confirmado', icon: '✓' },
    { status: 'picking_up', label: 'Coletando', icon: '📦' },
    { status: 'in_transit', label: 'Em trânsito', icon: '🛵' },
    { status: 'delivered', label: 'Entregue', icon: '✅' },
  ];

  const currentStepIndex = statusSteps.findIndex(s => s.status === delivery.status);

  return (
    <div className="min-h-screen bg-slate-50 pb-8">
      {/* Header */}
      <div className="bg-white px-5 pt-12 pb-4 border-b border-slate-100">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('/')}
            className="rounded-xl"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="font-semibold text-slate-900">
              {isCompleted ? 'Entrega concluída!' : 'Acompanhando entrega'}
            </h1>
            <p className="text-xs text-slate-500">#{deliveryId.slice(-8).toUpperCase()}</p>
          </div>
        </div>
      </div>

      {/* Status Progress */}
      <div className="bg-white px-5 py-6">
        <div className="flex items-center justify-between">
          {statusSteps.map((step, index) => (
            <div key={step.status} className="flex flex-col items-center relative">
              <div className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center text-lg transition-all",
                index <= currentStepIndex
                  ? "bg-emerald-600 text-white"
                  : "bg-slate-100 text-slate-400"
              )}>
                {index < currentStepIndex ? <Check className="w-5 h-5" /> : step.icon}
              </div>
              <p className={cn(
                "text-xs mt-2 text-center",
                index <= currentStepIndex ? "text-emerald-600 font-medium" : "text-slate-400"
              )}>
                {step.label}
              </p>
              {index < statusSteps.length - 1 && (
                <div className={cn(
                  "absolute top-5 left-full w-full h-0.5 -translate-y-1/2",
                  index < currentStepIndex ? "bg-emerald-400" : "bg-slate-200"
                )} style={{ width: 'calc(100% - 2.5rem)', left: '2.5rem' }} />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="p-5 space-y-4">
        {/* Driver Info */}
        {delivery.driver && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100"
          >
            <div className="flex items-center gap-4">
              <Avatar className="w-14 h-14 ring-4 ring-emerald-100">
                <AvatarImage src={delivery.driver.photo} />
                <AvatarFallback className="bg-emerald-100 text-emerald-600 text-lg font-bold">
                  {delivery.driver.name.charAt(0)}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1">
                <h3 className="font-semibold text-slate-900">{delivery.driver.name}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <div className="flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded-full">
                    <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                    <span className="text-xs font-medium text-amber-700">{delivery.driver.rating}</span>
                  </div>
                  <span className="text-xs text-slate-500">{delivery.driver.vehicle_model}</span>
                </div>
              </div>

              {!isCompleted && (
                <div className="flex gap-2">
                  <Button size="icon" variant="outline" className="w-10 h-10 rounded-xl">
                    <MessageCircle className="w-4 h-4" />
                  </Button>
                  <Button
                    size="icon"
                    className="w-10 h-10 rounded-xl bg-emerald-600 hover:bg-emerald-700"
                    onClick={() => window.open(`tel:${delivery.driver?.phone}`)}
                  >
                    <Phone className="w-4 h-4 text-white" />
                  </Button>
                </div>
              )}
            </div>
          </motion.div>
        )}

        {/* Route */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100"
        >
          <h4 className="font-semibold text-slate-900 mb-4">Trajeto</h4>
          <div className="flex items-start gap-3">
            <div className="flex flex-col items-center">
              <div className="w-3 h-3 rounded-full bg-blue-600" />
              <div className="w-0.5 h-16 bg-slate-200 my-1" />
              <div className="w-3 h-3 rounded-full bg-emerald-600" />
            </div>
            <div className="flex-1 space-y-4">
              <div>
                <p className="text-xs text-slate-500">Coleta</p>
                <p className="font-medium text-slate-900">{delivery.origin.address}</p>
                <p className="text-sm text-slate-500">{delivery.origin.contact_name}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500">Entrega</p>
                <p className="font-medium text-slate-900">{delivery.destination.address}</p>
                <p className="text-sm text-slate-500">{delivery.destination.contact_name}</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Package Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100"
        >
          <div className="flex items-center gap-3 mb-3">
            <Package className="w-5 h-5 text-emerald-600" />
            <h4 className="font-semibold text-slate-900">Pacote</h4>
          </div>
          <p className="text-slate-600">{delivery.package_info.description}</p>
          <p className="text-sm text-slate-500 mt-1">
            Tamanho: {delivery.package_info.size === 'small' ? 'Pequeno' : delivery.package_info.size === 'medium' ? 'Médio' : 'Grande'}
          </p>
        </motion.div>

        {/* Price */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-500">Valor</p>
              <p className="text-2xl font-bold text-slate-900">
                R$ {delivery.price.toFixed(2).replace('.', ',')}
              </p>
            </div>
            <div className="px-3 py-1.5 bg-emerald-100 text-emerald-700 rounded-lg text-sm font-medium">
              {delivery.payment_method === 'wallet' ? '💳 Carteira' : 
               delivery.payment_method === 'pix' ? '📱 PIX' : 
               delivery.payment_method === 'cash' ? '💵 Dinheiro' : '💳 Cartão'}
            </div>
          </div>
        </motion.div>

        {/* Completed Message */}
        {isCompleted && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-2xl p-6 text-center text-white"
          >
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold mb-2">Entrega concluída!</h3>
            <p className="text-emerald-100">
              Seu pacote foi entregue com sucesso.
            </p>
            <Button
              onClick={() => navigate('/')}
              className="mt-4 bg-white text-emerald-600 hover:bg-emerald-50"
            >
              Voltar ao início
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
}
