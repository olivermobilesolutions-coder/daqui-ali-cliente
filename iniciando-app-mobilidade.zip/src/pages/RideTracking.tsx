import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useRideSimulation } from '@/hooks/useRideSimulation';
import { ArrowLeft, AlertTriangle, MapPin, Phone, MessageCircle, Star, Navigation } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import CancelRideModal from '@/components/tracking/CancelRideModal';
import RatingModal from '@/components/tracking/RatingModal';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

export default function RideTracking() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const rideId = searchParams.get('id') || '';

  const [showCancelModal, setShowCancelModal] = useState(false);
  const [showRatingModal, setShowRatingModal] = useState(false);
  const [cancelling, setCancelling] = useState(false);

  const { ride, loading, driverEta, cancelRide, rateRide } = useRideSimulation({
    rideId,
    onCompleted: () => {
      setShowRatingModal(true);
    },
  });

  const handleCancelRide = async (reason: string) => {
    setCancelling(true);
    try {
      const { cancellationFee } = cancelRide(reason);
      if (cancellationFee > 0) {
        alert(`Corrida cancelada. Uma taxa de R$ ${cancellationFee.toFixed(2)} foi cobrada.`);
      }
      navigate('/');
    } catch (error) {
      console.error('Erro ao cancelar:', error);
    } finally {
      setCancelling(false);
      setShowCancelModal(false);
    }
  };

  const handleRateRide = async (rating: number, tip: number) => {
    rateRide(rating, tip);
    setShowRatingModal(false);
    navigate('/');
  };

  const handleEmergency = () => {
    window.open('https://wa.me/5511964527167?text=EMERGÊNCIA%20-%20Preciso%20de%20ajuda!', '_blank');
  };

  const handleCallDriver = () => {
    if (ride?.driver?.phone) {
      window.open(`tel:${ride.driver.phone}`);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4" />
          <p className="text-slate-600">Carregando corrida...</p>
        </div>
      </div>
    );
  }

  if (!ride) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6">
        <p className="text-slate-600 mb-4">Corrida não encontrada</p>
        <Button onClick={() => navigate('/')}>
          Voltar ao início
        </Button>
      </div>
    );
  }

  const isCompleted = ride.status === 'completed';
  const isCancelled = ride.status === 'cancelled';
  const isSearching = ['pending', 'searching'].includes(ride.status);
  const hasDriver = ride.driver && !isSearching;
  const canCancel = !isCompleted && !isCancelled;
  const driverArrived = ['driver_arriving', 'arrived', 'in_progress'].includes(ride.status);

  const statusConfig: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
    pending: { label: 'Buscando motorista...', color: 'bg-amber-500', icon: <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" /> },
    searching: { label: 'Buscando motorista...', color: 'bg-amber-500', icon: <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" /> },
    accepted: { label: 'Motorista confirmado!', color: 'bg-blue-500', icon: '✓' },
    driver_arriving: { label: `Chegando em ${driverEta} min`, color: 'bg-blue-600', icon: <Navigation className="w-5 h-5" /> },
    arrived: { label: 'Motorista chegou!', color: 'bg-emerald-500', icon: <MapPin className="w-5 h-5" /> },
    in_progress: { label: 'Em viagem', color: 'bg-indigo-600', icon: '🚗' },
    completed: { label: 'Corrida finalizada', color: 'bg-emerald-600', icon: '✓' },
    cancelled: { label: 'Corrida cancelada', color: 'bg-red-500', icon: '✕' },
  };

  const currentStatus = statusConfig[ride.status] || statusConfig.pending;

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      {/* Header */}
      <div className="bg-white px-5 pt-12 pb-4 border-b border-slate-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('/')}
              className="rounded-xl"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="font-semibold text-slate-900">
                {isCompleted ? 'Corrida finalizada' : isCancelled ? 'Corrida cancelada' : 'Acompanhando corrida'}
              </h1>
              <p className="text-xs text-slate-500">
                #{rideId.slice(-8).toUpperCase()}
              </p>
            </div>
          </div>
          
          {canCancel && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleEmergency}
              className="rounded-xl border-red-200 text-red-600 hover:bg-red-50"
            >
              <AlertTriangle className="w-4 h-4 mr-1" />
              Ajuda
            </Button>
          )}
        </div>
      </div>

      {/* Status Banner */}
      <div className={cn("px-5 py-4", currentStatus.color)}>
        <div className="flex items-center justify-center gap-3 text-white">
          <span className="text-xl">{currentStatus.icon}</span>
          <p className="font-semibold">{currentStatus.label}</p>
        </div>
      </div>

      {/* Map Placeholder */}
      <div className="h-48 bg-gradient-to-br from-blue-100 to-blue-50 flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0">
          {isSearching && (
            <>
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-blue-400/20 rounded-full animate-ping" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 bg-blue-500/30 rounded-full animate-ping" style={{ animationDelay: '0.5s' }} />
            </>
          )}
          {hasDriver && (
            <>
              <div className="absolute top-1/4 left-1/4 w-4 h-4 bg-blue-600 rounded-full shadow-lg" />
              <div className="absolute bottom-1/4 right-1/4 w-4 h-4 bg-emerald-600 rounded-full shadow-lg" />
              {ride.status === 'in_progress' && (
                <div 
                  className="absolute top-1/3 left-1/3 w-6 h-6 bg-indigo-600 rounded-full shadow-lg animate-pulse"
                  style={{
                    animation: 'moveDriver 3s ease-in-out infinite',
                  }}
                />
              )}
            </>
          )}
        </div>
        <div className="text-center z-10">
          <MapPin className="w-12 h-12 text-blue-600 mx-auto mb-2" />
          <p className="text-slate-600 text-sm">Acompanhamento em tempo real</p>
        </div>
      </div>

      {/* Content */}
      <div className="p-5 space-y-4">
        {/* Driver Info */}
        {hasDriver && ride.driver && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100"
          >
            <div className="flex items-center gap-4">
              <Avatar className="w-16 h-16 ring-4 ring-blue-100">
                <AvatarImage src={ride.driver.photo} />
                <AvatarFallback className="bg-blue-100 text-blue-600 text-xl font-bold">
                  {ride.driver.name.charAt(0)}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1">
                <h3 className="font-semibold text-slate-900 text-lg">{ride.driver.name}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <div className="flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded-full">
                    <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                    <span className="text-xs font-medium text-amber-700">{ride.driver.rating}</span>
                  </div>
                  <span className="text-xs text-slate-400">•</span>
                  <span className="text-xs text-slate-500">{ride.driver.vehicle_model}</span>
                </div>
                <p className="text-sm font-medium text-slate-900 mt-1">{ride.driver.vehicle_plate}</p>
              </div>

              {!isCompleted && !isCancelled && (
                <div className="flex gap-2">
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={() => navigate('/Chat')}
                    className="w-12 h-12 rounded-xl"
                  >
                    <MessageCircle className="w-5 h-5" />
                  </Button>
                  <Button
                    size="icon"
                    onClick={handleCallDriver}
                    className="w-12 h-12 rounded-xl bg-emerald-600 hover:bg-emerald-700"
                  >
                    <Phone className="w-5 h-5 text-white" />
                  </Button>
                </div>
              )}
            </div>

            {/* Vehicle info */}
            <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-500">Veículo</p>
                <p className="font-medium text-slate-900">{ride.driver.vehicle_model} • {ride.driver.vehicle_color}</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-slate-500">Placa</p>
                <p className="font-mono font-bold text-lg text-slate-900">{ride.driver.vehicle_plate}</p>
              </div>
            </div>
          </motion.div>
        )}

        {/* Route Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100"
        >
          <h4 className="font-semibold text-slate-900 mb-4">Trajeto</h4>
          <div className="flex items-start gap-3">
            <div className="flex flex-col items-center">
              <div className="w-3 h-3 rounded-full bg-blue-600" />
              <div className="w-0.5 h-12 bg-slate-200 my-1" />
              <div className="w-3 h-3 rounded-full bg-emerald-600" />
            </div>
            <div className="flex-1 space-y-4">
              <div>
                <p className="text-xs text-slate-500">Origem</p>
                <p className="font-medium text-slate-900">{ride.origin?.address || 'Localização atual'}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500">Destino</p>
                <p className="font-medium text-slate-900">{ride.destination?.address || 'Destino'}</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Price Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-500">Valor da corrida</p>
              <p className="text-2xl font-bold text-slate-900">
                R$ {(ride.final_price || ride.price)?.toFixed(2).replace('.', ',') || '0,00'}
              </p>
            </div>
            <div className="px-3 py-1.5 bg-slate-100 rounded-lg">
              <p className="text-xs text-slate-600 font-medium">
                {ride.payment_method === 'wallet' && '💳 Carteira'}
                {ride.payment_method === 'pix' && '📱 PIX'}
                {ride.payment_method === 'card' && '💳 Cartão'}
                {ride.payment_method === 'cash' && '💵 Dinheiro'}
              </p>
            </div>
          </div>
          
          {ride.estimated_distance && ride.estimated_time && (
            <div className="mt-3 pt-3 border-t border-slate-100 flex justify-between text-sm">
              <span className="text-slate-500">Distância: {ride.estimated_distance.toFixed(1)} km</span>
              <span className="text-slate-500">Tempo: ~{ride.estimated_time} min</span>
            </div>
          )}
        </motion.div>
      </div>

      {/* Bottom Actions */}
      {canCancel && (
        <div className="fixed bottom-0 left-0 right-0 p-5 bg-white border-t border-slate-100">
          <Button
            variant="outline"
            onClick={() => setShowCancelModal(true)}
            className="w-full h-12 rounded-xl border-red-200 text-red-600 hover:bg-red-50"
          >
            Cancelar corrida
          </Button>
        </div>
      )}

      {/* Cancel Modal */}
      <CancelRideModal
        open={showCancelModal}
        onClose={() => setShowCancelModal(false)}
        onConfirm={handleCancelRide}
        driverArrived={driverArrived}
        loading={cancelling}
      />

      {/* Rating Modal */}
      <RatingModal
        open={showRatingModal}
        driverName={ride.driver?.name || 'Motorista'}
        onSubmit={handleRateRide}
      />
    </div>
  );
}
