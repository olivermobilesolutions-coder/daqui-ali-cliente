import { useState, useEffect, useCallback, useRef } from 'react';
import * as storage from '@/lib/storage';

type RideStatus = storage.Ride['status'];

interface UseRideSimulationOptions {
  rideId: string;
  onStatusChange?: (status: RideStatus, ride: storage.Ride) => void;
  onCompleted?: (ride: storage.Ride) => void;
}

export function useRideSimulation({ rideId, onStatusChange, onCompleted }: UseRideSimulationOptions) {
  const [ride, setRide] = useState<storage.Ride | null>(null);
  const [loading, setLoading] = useState(true);
  const [driverEta, setDriverEta] = useState<number>(0);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const etaIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Load ride data
  const loadRide = useCallback(() => {
    const rideData = storage.getRideById(rideId);
    if (rideData) {
      setRide(rideData);
      if (rideData.driver_eta) {
        setDriverEta(rideData.driver_eta);
      }
    }
    setLoading(false);
    return rideData;
  }, [rideId]);

  // Update ride status
  const updateStatus = useCallback((newStatus: RideStatus, extraData?: Partial<storage.Ride>) => {
    const updated = storage.updateRide(rideId, { 
      status: newStatus,
      ...extraData 
    });
    if (updated) {
      setRide(updated);
      onStatusChange?.(newStatus, updated);
      if (newStatus === 'completed') {
        onCompleted?.(updated);
      }
    }
    return updated;
  }, [rideId, onStatusChange, onCompleted]);

  // Simulate finding driver
  const simulateFindDriver = useCallback(() => {
    // Wait 2-4 seconds to "find" a driver
    const delay = 2000 + Math.random() * 2000;
    
    setTimeout(() => {
      const currentRide = storage.getRideById(rideId);
      if (!currentRide || currentRide.status !== 'searching') return;
      
      // Assign random driver
      const driver = storage.getRandomDriver(currentRide.type);
      const eta = 3 + Math.floor(Math.random() * 5); // 3-7 minutes
      
      const updated = storage.updateRide(rideId, {
        status: 'accepted',
        driver,
        driver_eta: eta,
      });
      
      if (updated) {
        setRide(updated);
        setDriverEta(eta);
        onStatusChange?.('accepted', updated);
      }
    }, delay);
  }, [rideId, onStatusChange]);

  // Simulate ride progression
  const startSimulation = useCallback(() => {
    // Clear any existing intervals
    if (intervalRef.current) clearInterval(intervalRef.current);
    if (etaIntervalRef.current) clearInterval(etaIntervalRef.current);

    const progressRide = () => {
      const currentRide = storage.getRideById(rideId);
      if (!currentRide || currentRide.status === 'cancelled' || currentRide.status === 'completed') {
        if (intervalRef.current) clearInterval(intervalRef.current);
        return;
      }

      // Find current step based on status
      const statusOrder: RideStatus[] = ['pending', 'searching', 'accepted', 'driver_arriving', 'arrived', 'in_progress', 'completed'];
      const currentIndex = statusOrder.indexOf(currentRide.status);
      
      // Progress to next status
      const nextStatuses: RideStatus[] = ['driver_arriving', 'arrived', 'in_progress', 'completed'];
      const nextIndex = nextStatuses.findIndex(s => statusOrder.indexOf(s) > currentIndex);
      
      if (nextIndex >= 0 && nextIndex < nextStatuses.length) {
        const nextStatus = nextStatuses[nextIndex];
        const extraData: Partial<storage.Ride> = {};
        
        if (nextStatus === 'in_progress') {
          extraData.started_at = new Date().toISOString();
        }
        if (nextStatus === 'completed') {
          extraData.completed_at = new Date().toISOString();
          extraData.final_price = currentRide.price;
        }
        
        updateStatus(nextStatus, extraData);
      }
    };

    // Start progression interval
    intervalRef.current = setInterval(progressRide, 8000);

    // ETA countdown
    etaIntervalRef.current = setInterval(() => {
      setDriverEta(prev => {
        if (prev <= 0) return 0;
        const currentRide = storage.getRideById(rideId);
        if (currentRide?.status === 'arrived' || currentRide?.status === 'in_progress' || currentRide?.status === 'completed') {
          return 0;
        }
        return prev - 1;
      });
    }, 60000); // Update every minute

  }, [rideId, updateStatus]);

  // Cancel ride
  const cancelRide = useCallback((reason: string) => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    if (etaIntervalRef.current) clearInterval(etaIntervalRef.current);

    const currentRide = storage.getRideById(rideId);
    const driverArrived = ['driver_arriving', 'arrived', 'in_progress'].includes(currentRide?.status || '');
    
    let cancellationFee = 0;
    if (driverArrived) {
      cancellationFee = 5;
      const user = storage.getUser();
      if (user.wallet_balance >= cancellationFee) {
        storage.deductBalance(cancellationFee);
        storage.createTransaction({
          type: 'cancellation_fee',
          amount: -cancellationFee,
          description: 'Taxa de cancelamento',
          reference_id: rideId,
          reference_type: 'ride',
        });
      }
    }

    const updated = updateStatus('cancelled', {
      cancelled_at: new Date().toISOString(),
      cancellation_reason: reason,
    });

    return { ride: updated, cancellationFee };
  }, [rideId, updateStatus]);

  // Rate ride
  const rateRide = useCallback((rating: number, tip?: number) => {
    const extraData: Partial<storage.Ride> = { rating };
    
    if (tip && tip > 0) {
      extraData.tip = tip;
      storage.deductBalance(tip);
      storage.createTransaction({
        type: 'tip',
        amount: -tip,
        description: 'Gorjeta para motorista',
        reference_id: rideId,
        reference_type: 'ride',
      });
    }
    
    return storage.updateRide(rideId, extraData);
  }, [rideId]);

  // Initialize
  useEffect(() => {
    const rideData = loadRide();
    
    if (rideData) {
      if (rideData.status === 'pending') {
        // Change to searching
        updateStatus('searching');
        simulateFindDriver();
      } else if (rideData.status === 'searching') {
        simulateFindDriver();
      } else if (['accepted', 'driver_arriving', 'arrived', 'in_progress'].includes(rideData.status)) {
        startSimulation();
      }
    }

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (etaIntervalRef.current) clearInterval(etaIntervalRef.current);
    };
  }, [rideId]);

  // Start simulation when driver is assigned
  useEffect(() => {
    if (ride?.status === 'accepted' && ride.driver) {
      startSimulation();
    }
  }, [ride?.status, ride?.driver, startSimulation]);

  return {
    ride,
    loading,
    driverEta,
    cancelRide,
    rateRide,
    refresh: loadRide,
  };
}

// Similar hook for delivery simulation
export function useDeliverySimulation(deliveryId: string) {
  const [delivery, setDelivery] = useState<storage.Delivery | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const data = storage.getDeliveryById(deliveryId);
    setDelivery(data || null);
    setLoading(false);

    if (data && data.status === 'pending') {
      // Simulate driver acceptance
      setTimeout(() => {
        const driver = storage.getRandomDriver('moto');
        const updated = storage.updateDelivery(deliveryId, {
          status: 'accepted',
          driver,
        });
        if (updated) setDelivery(updated);
      }, 3000);
    }
  }, [deliveryId]);

  const updateStatus = useCallback((status: storage.Delivery['status']) => {
    const updated = storage.updateDelivery(deliveryId, { status });
    if (updated) setDelivery(updated);
    return updated;
  }, [deliveryId]);

  return { delivery, loading, updateStatus };
}
