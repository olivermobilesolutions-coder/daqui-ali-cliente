import { useState, useEffect, useCallback } from 'react';
import * as storage from '@/lib/storage';

// User hook
export function useUser() {
  const [user, setUser] = useState<storage.User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const userData = storage.getUser();
    setUser(userData);
    setLoading(false);
  }, []);

  const updateUser = useCallback((data: Partial<storage.User>) => {
    const updated = storage.updateUser(data);
    setUser(updated);
    return updated;
  }, []);

  const addBalance = useCallback((amount: number) => {
    const updated = storage.addBalance(amount);
    setUser(updated);
    
    // Create transaction
    storage.createTransaction({
      type: 'deposit',
      amount,
      description: 'Depósito via PIX',
    });
    
    return updated;
  }, []);

  const deductBalance = useCallback((amount: number, description: string, referenceId?: string, referenceType?: 'ride' | 'delivery' | 'freight') => {
    const updated = storage.deductBalance(amount);
    setUser(updated);
    
    // Create transaction
    storage.createTransaction({
      type: 'payment',
      amount: -amount,
      description,
      reference_id: referenceId,
      reference_type: referenceType,
    });
    
    return updated;
  }, []);

  const refreshUser = useCallback(() => {
    const userData = storage.getUser();
    setUser(userData);
  }, []);

  return { user, loading, updateUser, addBalance, deductBalance, refreshUser };
}

// Rides hook
export function useRides() {
  const [rides, setRides] = useState<storage.Ride[]>([]);
  const [loading, setLoading] = useState(true);

  const loadRides = useCallback(() => {
    const data = storage.getRides();
    setRides(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadRides();
  }, [loadRides]);

  const createRide = useCallback((data: Omit<storage.Ride, 'id' | 'created_at'>) => {
    const ride = storage.createRide(data);
    setRides(prev => [ride, ...prev]);
    return ride;
  }, []);

  const updateRide = useCallback((id: string, data: Partial<storage.Ride>) => {
    const updated = storage.updateRide(id, data);
    if (updated) {
      setRides(prev => prev.map(r => r.id === id ? updated : r));
    }
    return updated;
  }, []);

  const getRideById = useCallback((id: string) => {
    return storage.getRideById(id);
  }, []);

  return { rides, loading, createRide, updateRide, getRideById, refresh: loadRides };
}

// Deliveries hook
export function useDeliveries() {
  const [deliveries, setDeliveries] = useState<storage.Delivery[]>([]);
  const [loading, setLoading] = useState(true);

  const loadDeliveries = useCallback(() => {
    const data = storage.getDeliveries();
    setDeliveries(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadDeliveries();
  }, [loadDeliveries]);

  const createDelivery = useCallback((data: Omit<storage.Delivery, 'id' | 'created_at'>) => {
    const delivery = storage.createDelivery(data);
    setDeliveries(prev => [delivery, ...prev]);
    return delivery;
  }, []);

  const updateDelivery = useCallback((id: string, data: Partial<storage.Delivery>) => {
    const updated = storage.updateDelivery(id, data);
    if (updated) {
      setDeliveries(prev => prev.map(d => d.id === id ? updated : d));
    }
    return updated;
  }, []);

  const getDeliveryById = useCallback((id: string) => {
    return storage.getDeliveryById(id);
  }, []);

  return { deliveries, loading, createDelivery, updateDelivery, getDeliveryById, refresh: loadDeliveries };
}

// Freights hook
export function useFreights() {
  const [freights, setFreights] = useState<storage.FreightRequest[]>([]);
  const [loading, setLoading] = useState(true);

  const loadFreights = useCallback(() => {
    const data = storage.getFreights();
    setFreights(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadFreights();
  }, [loadFreights]);

  const createFreight = useCallback((data: Omit<storage.FreightRequest, 'id' | 'created_at'>) => {
    const freight = storage.createFreight(data);
    setFreights(prev => [freight, ...prev]);
    return freight;
  }, []);

  const updateFreight = useCallback((id: string, data: Partial<storage.FreightRequest>) => {
    const updated = storage.updateFreight(id, data);
    if (updated) {
      setFreights(prev => prev.map(f => f.id === id ? updated : f));
    }
    return updated;
  }, []);

  const getFreightById = useCallback((id: string) => {
    return storage.getFreightById(id);
  }, []);

  return { freights, loading, createFreight, updateFreight, getFreightById, refresh: loadFreights };
}

// Transactions hook
export function useTransactions() {
  const [transactions, setTransactions] = useState<storage.Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  const loadTransactions = useCallback(() => {
    const data = storage.getTransactions();
    setTransactions(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadTransactions();
  }, [loadTransactions]);

  const createTransaction = useCallback((data: Omit<storage.Transaction, 'id' | 'created_at'>) => {
    const transaction = storage.createTransaction(data);
    setTransactions(prev => [transaction, ...prev]);
    return transaction;
  }, []);

  return { transactions, loading, createTransaction, refresh: loadTransactions };
}

// Addresses hook
export function useAddresses() {
  const [addresses, setAddresses] = useState<storage.SavedAddress[]>([]);
  const [loading, setLoading] = useState(true);

  const loadAddresses = useCallback(() => {
    const data = storage.getAddresses();
    setAddresses(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadAddresses();
  }, [loadAddresses]);

  const saveAddress = useCallback((data: Omit<storage.SavedAddress, 'id'>) => {
    const address = storage.saveAddress(data);
    setAddresses(prev => [...prev, address]);
    return address;
  }, []);

  const deleteAddress = useCallback((id: string) => {
    storage.deleteAddress(id);
    setAddresses(prev => prev.filter(a => a.id !== id));
  }, []);

  return { addresses, loading, saveAddress, deleteAddress, refresh: loadAddresses };
}

// Notifications hook
export function useNotifications() {
  const [notifications, setNotifications] = useState<storage.Notification[]>([]);
  const [loading, setLoading] = useState(true);

  const loadNotifications = useCallback(() => {
    const data = storage.getNotifications();
    setNotifications(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadNotifications();
  }, [loadNotifications]);

  const markRead = useCallback((id: string) => {
    storage.markNotificationRead(id);
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  }, []);

  const markAllRead = useCallback(() => {
    storage.markAllNotificationsRead();
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  }, []);

  const unreadCount = notifications.filter(n => !n.read).length;

  return { notifications, loading, markRead, markAllRead, unreadCount, refresh: loadNotifications };
}

// Price calculation hook
export function usePriceCalculation() {
  const calculateRidePrice = useCallback((
    type: 'moto' | 'car',
    distance: number,
    stops: number,
    preferences: { moto_quantity?: number; car_category?: string }
  ) => {
    const basePrice = type === 'moto' ? 5 : 8;
    const perKm = type === 'moto' ? 2 : 3;
    const stopsExtra = stops * 3;
    const motoExtra = type === 'moto' ? ((preferences.moto_quantity || 1) - 1) * 8 : 0;
    const categoryExtra = preferences.car_category === 'large_trunk' ? 5 : 0;
    
    const total = basePrice + (distance * perKm) + stopsExtra + motoExtra + categoryExtra;
    return Math.round(total * 100) / 100;
  }, []);

  const calculateDeliveryPrice = useCallback((
    distance: number,
    size: 'small' | 'medium' | 'large'
  ) => {
    const basePrice = 8;
    const perKm = 1.5;
    const sizeMultiplier = size === 'small' ? 1 : size === 'medium' ? 1.3 : 1.6;
    
    const total = (basePrice + (distance * perKm)) * sizeMultiplier;
    return Math.round(total * 100) / 100;
  }, []);

  const estimateDistance = useCallback((origin: string, destination: string) => {
    // Simple mock distance based on string lengths (would be replaced by real API)
    const baseDistance = 2;
    const variation = (origin.length + destination.length) % 10;
    return baseDistance + variation * 0.5;
  }, []);

  const estimateTime = useCallback((distance: number, type: 'moto' | 'car' | 'delivery') => {
    const avgSpeed = type === 'moto' ? 25 : type === 'car' ? 20 : 30; // km/h
    return Math.ceil((distance / avgSpeed) * 60); // minutes
  }, []);

  return { calculateRidePrice, calculateDeliveryPrice, estimateDistance, estimateTime };
}
