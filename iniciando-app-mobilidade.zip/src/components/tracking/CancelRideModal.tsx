import { useState } from 'react';
import { AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';

interface CancelRideModalProps {
  open: boolean;
  onClose: () => void;
  onConfirm: (reason: string) => void;
  driverArrived: boolean;
  loading: boolean;
}

export default function CancelRideModal({ open, onClose, onConfirm, driverArrived, loading }: CancelRideModalProps) {
  const [selectedReason, setSelectedReason] = useState('');

  const reasons = [
    'Tempo de espera muito longo',
    'Encontrei outra alternativa',
    'Motorista pediu para cancelar',
    'Erro no endereço',
    'Mudei de ideia',
    'Outro motivo'
  ];

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-500" />
            Cancelar corrida
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {driverArrived && (
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
              <p className="text-sm text-amber-800">
                <strong>Atenção:</strong> O motorista já está a caminho. Uma taxa de cancelamento de R$ 5,00 pode ser aplicada.
              </p>
            </div>
          )}

          <div>
            <p className="text-sm text-slate-600 mb-3">Por que você quer cancelar?</p>
            <div className="space-y-2">
              {reasons.map((reason) => (
                <button
                  key={reason}
                  onClick={() => setSelectedReason(reason)}
                  className={cn(
                    "w-full p-3 rounded-xl text-left text-sm transition-all",
                    selectedReason === reason
                      ? "bg-blue-50 border-2 border-blue-600 text-blue-900"
                      : "bg-slate-50 border-2 border-transparent hover:bg-slate-100"
                  )}
                >
                  {reason}
                </button>
              ))}
            </div>
          </div>

          <div className="flex gap-3 pt-2">
            <Button
              variant="outline"
              onClick={onClose}
              className="flex-1 h-12 rounded-xl"
            >
              Voltar
            </Button>
            <Button
              onClick={() => onConfirm(selectedReason)}
              disabled={!selectedReason || loading}
              className="flex-1 h-12 rounded-xl bg-red-600 hover:bg-red-700 text-white"
            >
              {loading ? 'Cancelando...' : 'Confirmar cancelamento'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
