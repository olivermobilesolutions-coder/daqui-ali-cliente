import { Check, Clock, Navigation, Car, Flag } from 'lucide-react';
import { cn } from '@/lib/utils';

interface RideStatusProps {
  status: string;
}

export default function RideStatus({ status }: RideStatusProps) {
  const steps = [
    { id: 'pending', label: 'Buscando', icon: Clock },
    { id: 'accepted', label: 'Confirmado', icon: Check },
    { id: 'driver_arriving', label: 'A caminho', icon: Navigation },
    { id: 'in_progress', label: 'Em viagem', icon: Car },
    { id: 'completed', label: 'Finalizado', icon: Flag },
  ];

  const currentIndex = steps.findIndex(s => s.id === status);

  return (
    <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
      <div className="flex items-center justify-between">
        {steps.map((step, index) => {
          const isActive = index <= currentIndex;
          const isCurrent = step.id === status;
          const Icon = step.icon;

          return (
            <div key={step.id} className="flex flex-col items-center relative">
              <div className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center transition-all",
                isCurrent ? "bg-blue-600 text-white scale-110" :
                isActive ? "bg-emerald-100 text-emerald-600" :
                "bg-slate-100 text-slate-400"
              )}>
                <Icon className="w-5 h-5" />
              </div>
              <p className={cn(
                "text-xs mt-2 text-center",
                isCurrent ? "text-blue-600 font-semibold" :
                isActive ? "text-slate-700" : "text-slate-400"
              )}>
                {step.label}
              </p>
              
              {index < steps.length - 1 && (
                <div className={cn(
                  "absolute top-5 left-full w-full h-0.5 -translate-y-1/2",
                  index < currentIndex ? "bg-emerald-400" : "bg-slate-200"
                )} style={{ width: 'calc(100% - 2.5rem)', left: '2.5rem' }} />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
