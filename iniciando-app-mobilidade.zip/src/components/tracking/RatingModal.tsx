import { useState } from 'react';
import { Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';

interface RatingModalProps {
  open: boolean;
  driverName: string;
  onSubmit: (rating: number, tip: number) => void;
}

export default function RatingModal({ open, driverName, onSubmit }: RatingModalProps) {
  const [rating, setRating] = useState(5);
  const [tip, setTip] = useState('');
  const [hoveredRating, setHoveredRating] = useState(0);

  const tipOptions = [0, 2, 5, 10];

  const handleSubmit = () => {
    onSubmit(rating, parseFloat(tip) || 0);
  };

  return (
    <Dialog open={open} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center">Como foi sua viagem?</DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Driver name */}
          <p className="text-center text-slate-600">
            Avalie sua experiência com <span className="font-semibold">{driverName}</span>
          </p>

          {/* Star Rating */}
          <div className="flex justify-center gap-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                onClick={() => setRating(star)}
                onMouseEnter={() => setHoveredRating(star)}
                onMouseLeave={() => setHoveredRating(0)}
                className="p-1 transition-transform hover:scale-110"
              >
                <Star
                  className={cn(
                    "w-10 h-10 transition-colors",
                    (hoveredRating || rating) >= star
                      ? "text-amber-400 fill-amber-400"
                      : "text-slate-300"
                  )}
                />
              </button>
            ))}
          </div>

          {/* Rating Label */}
          <p className="text-center font-medium text-slate-900">
            {rating === 1 && 'Muito ruim 😞'}
            {rating === 2 && 'Ruim 😕'}
            {rating === 3 && 'Regular 😐'}
            {rating === 4 && 'Bom 😊'}
            {rating === 5 && 'Excelente! 🌟'}
          </p>

          {/* Tip Section */}
          <div className="bg-slate-50 rounded-xl p-4">
            <p className="text-sm font-medium text-slate-900 mb-3">
              Deseja dar uma gorjeta? (opcional)
            </p>
            
            <div className="flex gap-2 mb-3">
              {tipOptions.map((amount) => (
                <button
                  key={amount}
                  onClick={() => setTip(amount === 0 ? '' : String(amount))}
                  className={cn(
                    "flex-1 py-2 rounded-lg text-sm font-medium transition-all",
                    (tip === '' && amount === 0) || tip === String(amount)
                      ? "bg-blue-600 text-white"
                      : "bg-white border border-slate-200 text-slate-600 hover:border-blue-300"
                  )}
                >
                  {amount === 0 ? 'Não' : `R$ ${amount}`}
                </button>
              ))}
            </div>

            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 font-medium">
                R$
              </span>
              <Input
                type="number"
                placeholder="Outro valor"
                value={tip}
                onChange={(e) => setTip(e.target.value)}
                className="h-12 rounded-xl pl-12"
              />
            </div>
          </div>

          {/* Submit Button */}
          <Button
            onClick={handleSubmit}
            className="w-full h-14 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold"
          >
            {tip && parseFloat(tip) > 0 
              ? `Avaliar e dar R$ ${parseFloat(tip).toFixed(2).replace('.', ',')} de gorjeta`
              : 'Enviar avaliação'
            }
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
