import { Phone, MessageCircle, Star } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';

interface Driver {
  name: string;
  photo: string;
  rating: number;
  vehicle_model: string;
  vehicle_plate: string;
}

interface DriverInfoProps {
  driver: Driver;
  onCall: () => void;
  onChat: () => void;
}

export default function DriverInfo({ driver, onCall, onChat }: DriverInfoProps) {
  return (
    <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
      <div className="flex items-center gap-4">
        <Avatar className="w-14 h-14">
          <AvatarImage src={driver.photo} />
          <AvatarFallback className="bg-blue-100 text-blue-600 text-lg font-bold">
            {driver.name.charAt(0)}
          </AvatarFallback>
        </Avatar>
        
        <div className="flex-1">
          <h3 className="font-semibold text-slate-900">{driver.name}</h3>
          <div className="flex items-center gap-2 mt-1">
            <div className="flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded-full">
              <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
              <span className="text-xs font-medium text-amber-700">{driver.rating}</span>
            </div>
          </div>
        </div>

        <div className="flex gap-2">
          <Button
            size="icon"
            variant="outline"
            onClick={onChat}
            className="w-10 h-10 rounded-xl"
          >
            <MessageCircle className="w-4 h-4" />
          </Button>
          <Button
            size="icon"
            onClick={onCall}
            className="w-10 h-10 rounded-xl bg-emerald-600 hover:bg-emerald-700"
          >
            <Phone className="w-4 h-4 text-white" />
          </Button>
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-slate-100">
        <div className="flex items-center justify-between text-sm">
          <div>
            <p className="text-slate-500">Veículo</p>
            <p className="font-medium text-slate-900">{driver.vehicle_model}</p>
          </div>
          <div className="text-right">
            <p className="text-slate-500">Placa</p>
            <p className="font-medium text-slate-900">{driver.vehicle_plate}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
