import { Clock, MapPin, Bike, Car } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface PriceEstimateProps {
  price: number;
  estimatedTime: number;
  distance: number;
  onConfirm: () => void;
  loading: boolean;
  type: string;
}

export default function PriceEstimate({ price, estimatedTime, distance, onConfirm, loading, type }: PriceEstimateProps) {
  const Icon = type === 'moto' ? Bike : Car;
  const bgColor = type === 'moto' ? 'bg-blue-100' : 'bg-indigo-100';
  const iconColor = type === 'moto' ? 'text-blue-600' : 'text-indigo-600';

  return (
    <div className="bg-slate-900 rounded-2xl p-5 text-white">
      <div className="flex items-center gap-4 mb-4">
        <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center", bgColor)}>
          <Icon className={cn("w-6 h-6", iconColor)} />
        </div>
        <div>
          <p className="text-sm text-slate-400">Valor estimado</p>
          <p className="text-3xl font-bold">
            R$ {price.toFixed(2).replace('.', ',')}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-5">
        <div className="bg-slate-800 rounded-xl p-3">
          <div className="flex items-center gap-2 mb-1">
            <Clock className="w-4 h-4 text-slate-400" />
            <span className="text-xs text-slate-400">Tempo estimado</span>
          </div>
          <p className="font-semibold">{estimatedTime} min</p>
        </div>
        <div className="bg-slate-800 rounded-xl p-3">
          <div className="flex items-center gap-2 mb-1">
            <MapPin className="w-4 h-4 text-slate-400" />
            <span className="text-xs text-slate-400">Distância</span>
          </div>
          <p className="font-semibold">{distance.toFixed(1)} km</p>
        </div>
      </div>

      <Button
        onClick={onConfirm}
        disabled={loading}
        className="w-full h-14 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold"
      >
        {loading ? (
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            <span>Buscando motoristas...</span>
          </div>
        ) : (
          'Confirmar corrida'
        )}
      </Button>
    </div>
  );
}
