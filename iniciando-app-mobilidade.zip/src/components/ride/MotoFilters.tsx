import { Users, UserCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';

interface Preferences {
  gender: string;
  moto_quantity: number;
  car_category: string;
  ac: boolean;
  music: boolean;
  silence: boolean;
  specific_driver_id: string;
}

interface MotoFiltersProps {
  preferences: Preferences;
  onPreferencesChange: (prefs: Preferences) => void;
}

export default function MotoFilters({ preferences, onPreferencesChange }: MotoFiltersProps) {
  const genderOptions = [
    { id: 'any', label: 'Qualquer' },
    { id: 'male', label: 'Masculino' },
    { id: 'female', label: 'Feminino' }
  ];

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
        <h3 className="font-semibold text-slate-900 mb-4">Preferências de condutor</h3>
        
        <Label className="text-xs text-slate-500">Gênero do motorista</Label>
        <div className="flex gap-2 mt-2">
          {genderOptions.map((option) => (
            <button
              key={option.id}
              onClick={() => onPreferencesChange({ ...preferences, gender: option.id })}
              className={cn(
                "flex-1 py-3 px-4 rounded-xl text-sm font-medium transition-all",
                preferences.gender === option.id
                  ? "bg-blue-600 text-white"
                  : "bg-slate-100 text-slate-600 hover:bg-slate-200"
              )}
            >
              {option.label}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
        <h3 className="font-semibold text-slate-900 mb-4">Quantidade de motos</h3>
        
        <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
          <div className="flex items-center gap-3">
            <Users className="w-5 h-5 text-slate-600" />
            <span className="font-medium">Passageiros</span>
          </div>
          <div className="flex items-center gap-3">
            <Button
              size="icon"
              variant="outline"
              onClick={() => onPreferencesChange({ 
                ...preferences, 
                moto_quantity: Math.max(1, preferences.moto_quantity - 1) 
              })}
              className="h-8 w-8 rounded-lg"
            >
              -
            </Button>
            <span className="w-8 text-center font-semibold">{preferences.moto_quantity}</span>
            <Button
              size="icon"
              variant="outline"
              onClick={() => onPreferencesChange({ 
                ...preferences, 
                moto_quantity: Math.min(5, preferences.moto_quantity + 1) 
              })}
              className="h-8 w-8 rounded-lg"
            >
              +
            </Button>
          </div>
        </div>
        <p className="text-xs text-slate-500 mt-2">
          Cada passageiro irá em uma moto separada
        </p>
      </div>

      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
        <h3 className="font-semibold text-slate-900 mb-2">Motorista específico (opcional)</h3>
        <p className="text-sm text-slate-500 mb-3">Informe o código do motorista preferido</p>
        <div className="relative">
          <UserCircle className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <Input
            placeholder="Código do motorista"
            value={preferences.specific_driver_id}
            onChange={(e) => onPreferencesChange({ ...preferences, specific_driver_id: e.target.value })}
            className="h-12 rounded-xl pl-10"
          />
        </div>
      </div>
    </div>
  );
}
