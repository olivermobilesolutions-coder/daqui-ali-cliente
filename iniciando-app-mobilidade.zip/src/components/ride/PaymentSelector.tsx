import { Wallet, CreditCard, Banknote, QrCode } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PaymentSelectorProps {
  selected: string;
  onSelect: (method: string) => void;
  walletBalance?: number;
}

export default function PaymentSelector({ selected, onSelect, walletBalance = 0 }: PaymentSelectorProps) {
  const methods = [
    { 
      id: 'wallet', 
      label: 'Carteira', 
      description: `Saldo: R$ ${walletBalance.toFixed(2).replace('.', ',')}`,
      icon: Wallet,
      color: 'bg-blue-100 text-blue-600'
    },
    { 
      id: 'pix', 
      label: 'PIX', 
      description: 'Pagamento instantâneo',
      icon: QrCode,
      color: 'bg-emerald-100 text-emerald-600'
    },
    { 
      id: 'card', 
      label: 'Cartão', 
      description: 'Crédito ou débito',
      icon: CreditCard,
      color: 'bg-purple-100 text-purple-600'
    },
    { 
      id: 'cash', 
      label: 'Dinheiro', 
      description: 'Pague ao motorista',
      icon: Banknote,
      color: 'bg-green-100 text-green-600'
    }
  ];

  return (
    <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
      <h3 className="font-semibold text-slate-900 mb-4">Forma de pagamento</h3>
      
      <div className="space-y-3">
        {methods.map((method) => (
          <button
            key={method.id}
            onClick={() => onSelect(method.id)}
            className={cn(
              "w-full flex items-center gap-4 p-4 rounded-xl border-2 text-left transition-all",
              selected === method.id
                ? "border-blue-600 bg-blue-50"
                : "border-slate-200 hover:border-slate-300"
            )}
          >
            <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center", method.color)}>
              <method.icon className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <p className="font-medium text-slate-900">{method.label}</p>
              <p className="text-sm text-slate-500">{method.description}</p>
            </div>
            <div className={cn(
              "w-5 h-5 rounded-full border-2 flex items-center justify-center",
              selected === method.id ? "border-blue-600 bg-blue-600" : "border-slate-300"
            )}>
              {selected === method.id && (
                <div className="w-2 h-2 rounded-full bg-white" />
              )}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
