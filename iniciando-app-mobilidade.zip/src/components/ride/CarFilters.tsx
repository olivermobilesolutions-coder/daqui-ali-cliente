import { Car, Snowflake, Music, VolumeX } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { cn } from '@/lib/utils';

interface Preferences {
  gender: string;
  moto_quantity: number;
  car_category: string;
  ac: boolean;
  music: boolean;
  silence: boolean;
  specific_driver_id: string;
}

interface CarFiltersProps {
  preferences: Preferences;
  onPreferencesChange: (prefs: Preferences) => void;
}

export default function CarFilters({ preferences, onPreferencesChange }: CarFiltersProps) {
  const categories = [
    { id: 'common', label: 'Comum', description: 'Carros populares' },
    { id: 'large_trunk', label: 'Porta-malas grande', description: 'Para mais bagagens' }
  ];

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
        <h3 className="font-semibold text-slate-900 mb-4">Categoria do veículo</h3>
        
        <div className="space-y-3">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => onPreferencesChange({ ...preferences, car_category: cat.id })}
              className={cn(
                "w-full flex items-center gap-4 p-4 rounded-xl border-2 text-left transition-all",
                preferences.car_category === cat.id
                  ? "border-blue-600 bg-blue-50"
                  : "border-slate-200 hover:border-slate-300"
              )}
            >
              <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center">
                <Car className="w-6 h-6 text-indigo-600" />
              </div>
              <div>
                <p className="font-medium text-slate-900">{cat.label}</p>
                <p className="text-sm text-slate-500">{cat.description}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
        <h3 className="font-semibold text-slate-900 mb-4">Preferências de viagem</h3>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
                <Snowflake className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="font-medium text-slate-900">Ar condicionado</p>
                <p className="text-xs text-slate-500">Veículo climatizado</p>
              </div>
            </div>
            <Switch
              checked={preferences.ac}
              onCheckedChange={(checked) => onPreferencesChange({ ...preferences, ac: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center">
                <Music className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="font-medium text-slate-900">Música</p>
                <p className="text-xs text-slate-500">Som ligado durante a viagem</p>
              </div>
            </div>
            <Switch
              checked={preferences.music}
              onCheckedChange={(checked) => onPreferencesChange({ ...preferences, music: checked, silence: checked ? false : preferences.silence })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center">
                <VolumeX className="w-5 h-5 text-slate-600" />
              </div>
              <div>
                <p className="font-medium text-slate-900">Silêncio</p>
                <p className="text-xs text-slate-500">Viagem sem conversas</p>
              </div>
            </div>
            <Switch
              checked={preferences.silence}
              onCheckedChange={(checked) => onPreferencesChange({ ...preferences, silence: checked, music: checked ? false : preferences.music })}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
