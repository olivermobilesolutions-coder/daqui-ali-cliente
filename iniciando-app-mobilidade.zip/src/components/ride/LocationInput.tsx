import { Plus, X, Navigation } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

interface Location {
  address: string;
  lat?: number;
  lng?: number;
}

interface LocationInputProps {
  origin: Location;
  destination: Location;
  stops: Location[];
  onOriginChange: (value: Location) => void;
  onDestinationChange: (value: Location) => void;
  onAddStop: () => void;
  onRemoveStop: (index: number) => void;
  onStopChange: (index: number, value: Location) => void;
  onUseCurrentLocation: () => void;
}

export default function LocationInput({
  origin,
  destination,
  stops,
  onOriginChange,
  onDestinationChange,
  onAddStop,
  onRemoveStop,
  onStopChange,
  onUseCurrentLocation
}: LocationInputProps) {
  return (
    <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
      <div className="flex items-start gap-3">
        <div className="flex flex-col items-center pt-3">
          <div className="w-3 h-3 rounded-full bg-blue-600" />
          <div className="w-0.5 flex-1 bg-slate-200 my-1" style={{ minHeight: stops.length > 0 ? `${40 + stops.length * 56}px` : '40px' }} />
          <div className="w-3 h-3 rounded-full bg-emerald-600" />
        </div>
        
        <div className="flex-1 space-y-3">
          <div>
            <p className="text-xs text-slate-500 mb-1">Origem</p>
            <div className="flex gap-2">
              <Input
                placeholder="De onde você vai sair?"
                value={origin.address}
                onChange={(e) => onOriginChange({ ...origin, address: e.target.value })}
                className="h-11 rounded-xl"
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={onUseCurrentLocation}
                className="h-11 w-11 rounded-xl shrink-0"
              >
                <Navigation className="w-4 h-4 text-blue-600" />
              </Button>
            </div>
          </div>

          {stops.map((stop, index) => (
            <div key={index}>
              <p className="text-xs text-slate-500 mb-1">Parada {index + 1}</p>
              <div className="flex gap-2">
                <Input
                  placeholder="Endereço da parada"
                  value={stop.address}
                  onChange={(e) => onStopChange(index, { ...stop, address: e.target.value })}
                  className="h-11 rounded-xl"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => onRemoveStop(index)}
                  className="h-11 w-11 rounded-xl shrink-0 text-red-500 hover:bg-red-50"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}

          <div>
            <p className="text-xs text-slate-500 mb-1">Destino</p>
            <Input
              placeholder="Para onde você vai?"
              value={destination.address}
              onChange={(e) => onDestinationChange({ ...destination, address: e.target.value })}
              className="h-11 rounded-xl"
            />
          </div>
        </div>
      </div>

      {stops.length < 10 && (
        <Button
          type="button"
          variant="outline"
          onClick={onAddStop}
          className="w-full mt-4 h-11 rounded-xl"
        >
          <Plus className="w-4 h-4 mr-2" />
          Adicionar parada
        </Button>
      )}
    </div>
  );
}
