import { useNavigate } from 'react-router-dom';
import { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ServiceCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  page: string;
  color: string;
  delay?: number;
}

export default function ServiceCard({ icon: Icon, title, description, page, color }: ServiceCardProps) {
  const navigate = useNavigate();

  return (
    <button
      onClick={() => navigate(`/${page}`)}
      className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 hover:shadow-md transition-all text-left w-full"
    >
      <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center mb-3", color)}>
        <Icon className="w-6 h-6 text-white" />
      </div>
      <h3 className="font-semibold text-slate-900">{title}</h3>
      <p className="text-sm text-slate-500">{description}</p>
    </button>
  );
}
