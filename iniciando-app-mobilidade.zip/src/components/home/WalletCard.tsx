import { Wallet, Plus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface WalletCardProps {
  balance: number;
  userName?: string;
}

export default function WalletCard({ balance, userName }: WalletCardProps) {
  const navigate = useNavigate();

  return (
    <div 
      onClick={() => navigate('/Wallet')}
      className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl p-5 text-white cursor-pointer hover:shadow-lg transition-shadow"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
            <Wallet className="w-5 h-5" />
          </div>
          <div>
            <p className="text-sm text-blue-200">Sua carteira</p>
            {userName && <p className="text-xs text-blue-300">Olá, {userName}</p>}
          </div>
        </div>
        <button className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center hover:bg-white/30 transition-colors">
          <Plus className="w-4 h-4" />
        </button>
      </div>
      <p className="text-3xl font-bold">
        R$ {balance.toFixed(2).replace('.', ',')}
      </p>
    </div>
  );
}
