import { HashRouter, Routes, Route, useLocation, useNavigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Home as HomeIcon, ClipboardList, MessageCircle, User } from 'lucide-react';
import { cn } from '@/lib/utils';

import Home from '@/pages/Home';
import RideRequest from '@/pages/RideRequest';
import RideTracking from '@/pages/RideTracking';
import DeliveryRequest from '@/pages/DeliveryRequest';
import DeliveryTracking from '@/pages/DeliveryTracking';
import FreightRequest from '@/pages/FreightRequest';
import History from '@/pages/History';
import Wallet from '@/pages/Wallet';
import Profile from '@/pages/Profile';
import Notifications from '@/pages/Notifications';
import Chat from '@/pages/Chat';

const queryClient = new QueryClient();

function BottomNav() {
  const location = useLocation();
  const navigate = useNavigate();
  
  const hideNavOn = ['/RideRequest', '/RideTracking', '/DeliveryRequest', '/DeliveryTracking', '/FreightRequest', '/Notifications'];
  const shouldHide = hideNavOn.some(path => location.pathname.startsWith(path));
  
  if (shouldHide) return null;

  const navItems = [
    { icon: HomeIcon, label: 'Início', path: '/' },
    { icon: ClipboardList, label: 'Histórico', path: '/History' },
    { icon: MessageCircle, label: 'Chat', path: '/Chat' },
    { icon: User, label: 'Perfil', path: '/Profile' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-100 px-6 py-3 flex justify-around items-center z-50">
      {navItems.map((item) => {
        const isActive = location.pathname === item.path || 
          (item.path === '/' && location.pathname === '/') ||
          (item.path !== '/' && location.pathname.startsWith(item.path));
        
        return (
          <button
            key={item.label}
            onClick={() => navigate(item.path)}
            className={cn(
              "flex flex-col items-center gap-1 transition-colors",
              isActive ? "text-blue-600" : "text-slate-400"
            )}
          >
            <item.icon className="w-6 h-6" />
            <span className="text-xs font-medium">{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
}

function AppContent() {
  const location = useLocation();
  const hideNavOn = ['/RideRequest', '/RideTracking', '/DeliveryRequest', '/DeliveryTracking', '/FreightRequest', '/Notifications'];
  const shouldHideNav = hideNavOn.some(path => location.pathname.startsWith(path));

  return (
    <div className={cn(!shouldHideNav && "pb-20")}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/RideRequest" element={<RideRequest />} />
        <Route path="/RideTracking" element={<RideTracking />} />
        <Route path="/DeliveryRequest" element={<DeliveryRequest />} />
        <Route path="/DeliveryTracking" element={<DeliveryTracking />} />
        <Route path="/FreightRequest" element={<FreightRequest />} />
        <Route path="/History" element={<History />} />
        <Route path="/Wallet" element={<Wallet />} />
        <Route path="/Profile" element={<Profile />} />
        <Route path="/Notifications" element={<Notifications />} />
        <Route path="/Chat" element={<Chat />} />
      </Routes>
      <BottomNav />
    </div>
  );
}

export function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <HashRouter>
        <AppContent />
      </HashRouter>
    </QueryClientProvider>
  );
}
