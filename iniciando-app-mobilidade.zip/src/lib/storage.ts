// Storage service with localStorage persistence
const STORAGE_KEYS = {
  USER: 'daquiali_user',
  RIDES: 'daquiali_rides',
  DELIVERIES: 'daquiali_deliveries',
  FREIGHTS: 'daquiali_freights',
  TRANSACTIONS: 'daquiali_transactions',
  ADDRESSES: 'daquiali_addresses',
  NOTIFICATIONS: 'daquiali_notifications',
};

// Generate unique ID
export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

// Generic storage functions
export function getItem<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch {
    return defaultValue;
  }
}

export function setItem<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error('Error saving to localStorage:', error);
  }
}

// User
export interface User {
  id: string;
  full_name: string;
  email: string;
  phone: string;
  wallet_balance: number;
  rating: number;
  total_rides: number;
  photo: string;
  referral_code: string;
  created_at: string;
}

export function getUser(): User {
  const defaultUser: User = {
    id: generateId(),
    full_name: 'Usuário Demo',
    email: 'demo@daquiali.com',
    phone: '11999999999',
    wallet_balance: 50.00,
    rating: 5.0,
    total_rides: 0,
    photo: '',
    referral_code: 'DEMO2024',
    created_at: new Date().toISOString(),
  };
  
  const user = getItem<User | null>(STORAGE_KEYS.USER, null);
  if (!user) {
    setItem(STORAGE_KEYS.USER, defaultUser);
    return defaultUser;
  }
  return user;
}

export function updateUser(data: Partial<User>): User {
  const user = getUser();
  const updatedUser = { ...user, ...data };
  setItem(STORAGE_KEYS.USER, updatedUser);
  return updatedUser;
}

export function addBalance(amount: number): User {
  const user = getUser();
  user.wallet_balance += amount;
  setItem(STORAGE_KEYS.USER, user);
  return user;
}

export function deductBalance(amount: number): User {
  const user = getUser();
  user.wallet_balance = Math.max(0, user.wallet_balance - amount);
  setItem(STORAGE_KEYS.USER, user);
  return user;
}

// Rides
export interface Location {
  address: string;
  lat?: number;
  lng?: number;
}

export interface RidePreferences {
  gender: string;
  moto_quantity: number;
  car_category: string;
  ac: boolean;
  music: boolean;
  silence: boolean;
  specific_driver_id: string;
}

export interface Driver {
  id: string;
  name: string;
  phone: string;
  photo: string;
  rating: number;
  vehicle_model: string;
  vehicle_plate: string;
  vehicle_color: string;
}

export interface Ride {
  id: string;
  type: 'moto' | 'car';
  status: 'pending' | 'searching' | 'accepted' | 'driver_arriving' | 'arrived' | 'in_progress' | 'completed' | 'cancelled';
  origin: Location;
  destination: Location;
  stops: Location[];
  price: number;
  final_price?: number;
  price_type: string;
  payment_method: string;
  preferences: RidePreferences;
  estimated_time: number;
  estimated_distance: number;
  driver?: Driver;
  driver_eta?: number;
  started_at?: string;
  completed_at?: string;
  cancelled_at?: string;
  cancellation_reason?: string;
  rating?: number;
  tip?: number;
  created_at: string;
}

export function getRides(): Ride[] {
  return getItem<Ride[]>(STORAGE_KEYS.RIDES, []);
}

export function createRide(data: Omit<Ride, 'id' | 'created_at'>): Ride {
  const rides = getRides();
  const ride: Ride = {
    ...data,
    id: generateId(),
    created_at: new Date().toISOString(),
  };
  rides.unshift(ride);
  setItem(STORAGE_KEYS.RIDES, rides);
  
  // Update user total rides
  const user = getUser();
  user.total_rides += 1;
  setItem(STORAGE_KEYS.USER, user);
  
  return ride;
}

export function updateRide(id: string, data: Partial<Ride>): Ride | null {
  const rides = getRides();
  const index = rides.findIndex(r => r.id === id);
  if (index === -1) return null;
  
  rides[index] = { ...rides[index], ...data };
  setItem(STORAGE_KEYS.RIDES, rides);
  return rides[index];
}

export function getRideById(id: string): Ride | undefined {
  return getRides().find(r => r.id === id);
}

// Deliveries
export interface DeliveryContact {
  address: string;
  contact_name: string;
  contact_phone: string;
}

export interface PackageInfo {
  description: string;
  weight: string;
  size: 'small' | 'medium' | 'large';
}

export interface Delivery {
  id: string;
  status: 'pending' | 'accepted' | 'picking_up' | 'in_transit' | 'delivered' | 'cancelled';
  origin: DeliveryContact;
  destination: DeliveryContact;
  package_info: PackageInfo;
  price: number;
  payment_method: string;
  driver?: Driver;
  created_at: string;
  completed_at?: string;
}

export function getDeliveries(): Delivery[] {
  return getItem<Delivery[]>(STORAGE_KEYS.DELIVERIES, []);
}

export function createDelivery(data: Omit<Delivery, 'id' | 'created_at'>): Delivery {
  const deliveries = getDeliveries();
  const delivery: Delivery = {
    ...data,
    id: generateId(),
    created_at: new Date().toISOString(),
  };
  deliveries.unshift(delivery);
  setItem(STORAGE_KEYS.DELIVERIES, deliveries);
  return delivery;
}

export function updateDelivery(id: string, data: Partial<Delivery>): Delivery | null {
  const deliveries = getDeliveries();
  const index = deliveries.findIndex(d => d.id === id);
  if (index === -1) return null;
  
  deliveries[index] = { ...deliveries[index], ...data };
  setItem(STORAGE_KEYS.DELIVERIES, deliveries);
  return deliveries[index];
}

export function getDeliveryById(id: string): Delivery | undefined {
  return getDeliveries().find(d => d.id === id);
}

// Freight Requests
export interface FreightItem {
  name: string;
  quantity: number;
}

export interface FreightPassengers {
  adults: number;
  children: number;
}

export interface FreightRequest {
  id: string;
  category: 'freight' | 'moving' | 'excursion';
  status: 'awaiting_quote' | 'proposal_sent' | 'accepted' | 'in_progress' | 'completed' | 'cancelled';
  origin: Location;
  destination: Location;
  items?: FreightItem[];
  passengers?: FreightPassengers;
  scheduled_date: string;
  offered_price?: number;
  final_price?: number;
  payment_method: string;
  notes?: string;
  driver?: Driver;
  proposals?: FreightProposal[];
  created_at: string;
}

export interface FreightProposal {
  id: string;
  driver_id: string;
  driver_name: string;
  driver_rating: number;
  price: number;
  message: string;
  created_at: string;
}

export function getFreights(): FreightRequest[] {
  return getItem<FreightRequest[]>(STORAGE_KEYS.FREIGHTS, []);
}

export function createFreight(data: Omit<FreightRequest, 'id' | 'created_at'>): FreightRequest {
  const freights = getFreights();
  const freight: FreightRequest = {
    ...data,
    id: generateId(),
    created_at: new Date().toISOString(),
  };
  freights.unshift(freight);
  setItem(STORAGE_KEYS.FREIGHTS, freights);
  return freight;
}

export function updateFreight(id: string, data: Partial<FreightRequest>): FreightRequest | null {
  const freights = getFreights();
  const index = freights.findIndex(f => f.id === id);
  if (index === -1) return null;
  
  freights[index] = { ...freights[index], ...data };
  setItem(STORAGE_KEYS.FREIGHTS, freights);
  return freights[index];
}

export function getFreightById(id: string): FreightRequest | undefined {
  return getFreights().find(f => f.id === id);
}

// Transactions
export interface Transaction {
  id: string;
  type: 'deposit' | 'payment' | 'tip' | 'refund' | 'referral_bonus' | 'cancellation_fee';
  amount: number;
  description: string;
  reference_id?: string;
  reference_type?: 'ride' | 'delivery' | 'freight';
  created_at: string;
}

export function getTransactions(): Transaction[] {
  return getItem<Transaction[]>(STORAGE_KEYS.TRANSACTIONS, []);
}

export function createTransaction(data: Omit<Transaction, 'id' | 'created_at'>): Transaction {
  const transactions = getTransactions();
  const transaction: Transaction = {
    ...data,
    id: generateId(),
    created_at: new Date().toISOString(),
  };
  transactions.unshift(transaction);
  setItem(STORAGE_KEYS.TRANSACTIONS, transactions);
  return transaction;
}

// Saved Addresses
export interface SavedAddress {
  id: string;
  label: string;
  address: string;
  type: 'home' | 'work' | 'other';
  lat?: number;
  lng?: number;
}

export function getAddresses(): SavedAddress[] {
  return getItem<SavedAddress[]>(STORAGE_KEYS.ADDRESSES, []);
}

export function saveAddress(data: Omit<SavedAddress, 'id'>): SavedAddress {
  const addresses = getAddresses();
  const address: SavedAddress = {
    ...data,
    id: generateId(),
  };
  addresses.push(address);
  setItem(STORAGE_KEYS.ADDRESSES, addresses);
  return address;
}

export function deleteAddress(id: string): void {
  const addresses = getAddresses().filter(a => a.id !== id);
  setItem(STORAGE_KEYS.ADDRESSES, addresses);
}

// Notifications
export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'promo';
  read: boolean;
  created_at: string;
}

export function getNotifications(): Notification[] {
  const defaultNotifications: Notification[] = [
    {
      id: '1',
      title: 'Bem-vindo ao Daqui Ali!',
      message: 'Você ganhou R$ 10 de bônus na sua primeira corrida.',
      type: 'promo',
      read: false,
      created_at: new Date().toISOString(),
    },
    {
      id: '2',
      title: 'Convide amigos',
      message: 'Ganhe R$ 5 por cada amigo que completar uma corrida.',
      type: 'info',
      read: false,
      created_at: new Date(Date.now() - 86400000).toISOString(),
    },
  ];
  
  const notifications = getItem<Notification[]>(STORAGE_KEYS.NOTIFICATIONS, []);
  if (notifications.length === 0) {
    setItem(STORAGE_KEYS.NOTIFICATIONS, defaultNotifications);
    return defaultNotifications;
  }
  return notifications;
}

export function markNotificationRead(id: string): void {
  const notifications = getNotifications();
  const notification = notifications.find(n => n.id === id);
  if (notification) {
    notification.read = true;
    setItem(STORAGE_KEYS.NOTIFICATIONS, notifications);
  }
}

export function markAllNotificationsRead(): void {
  const notifications = getNotifications().map(n => ({ ...n, read: true }));
  setItem(STORAGE_KEYS.NOTIFICATIONS, notifications);
}

// Mock Drivers for simulation
export const mockDrivers: Driver[] = [
  {
    id: 'd1',
    name: 'Carlos Silva',
    phone: '11988887777',
    photo: '',
    rating: 4.9,
    vehicle_model: 'Honda CG 160',
    vehicle_plate: 'ABC-1234',
    vehicle_color: 'Vermelha',
  },
  {
    id: 'd2',
    name: 'Ana Santos',
    phone: '11977776666',
    photo: '',
    rating: 4.8,
    vehicle_model: 'Honda Biz 125',
    vehicle_plate: 'DEF-5678',
    vehicle_color: 'Preta',
  },
  {
    id: 'd3',
    name: 'José Oliveira',
    phone: '11966665555',
    photo: '',
    rating: 4.7,
    vehicle_model: 'Toyota Corolla',
    vehicle_plate: 'GHI-9012',
    vehicle_color: 'Prata',
  },
  {
    id: 'd4',
    name: 'Maria Lima',
    phone: '11955554444',
    photo: '',
    rating: 5.0,
    vehicle_model: 'Chevrolet Onix',
    vehicle_plate: 'JKL-3456',
    vehicle_color: 'Branco',
  },
];

export function getRandomDriver(type: 'moto' | 'car'): Driver {
  if (type === 'moto') {
    return mockDrivers[Math.floor(Math.random() * 2)];
  }
  return mockDrivers[2 + Math.floor(Math.random() * 2)];
}

// Clear all data (for testing)
export function clearAllData(): void {
  Object.values(STORAGE_KEYS).forEach(key => {
    localStorage.removeItem(key);
  });
}
