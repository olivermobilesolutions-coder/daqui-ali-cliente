// Mock API client for Daqui Ali

const mockUser = {
  id: '1',
  full_name: 'João Silva',
  email: 'joao@email.com',
  phone: '11999999999',
  wallet_balance: 125.50,
  rating: 4.9,
  total_rides: 42,
  photo: '',
  referral_code: 'JOAO2024'
};

const mockRides: any[] = [];
const mockDeliveries: any[] = [];
const mockFreights: any[] = [];
const mockTransactions: any[] = [
  { id: '1', type: 'deposit', amount: 100, created_date: new Date().toISOString() },
  { id: '2', type: 'payment', amount: -25.50, created_date: new Date(Date.now() - 86400000).toISOString() },
  { id: '3', type: 'referral_bonus', amount: 5, created_date: new Date(Date.now() - 172800000).toISOString() },
];

function generateId() {
  return Math.random().toString(36).substring(2, 15);
}

export const base44 = {
  auth: {
    me: async () => mockUser,
    updateMe: async (data: any) => {
      Object.assign(mockUser, data);
      return mockUser;
    },
    logout: () => {
      window.location.href = '/';
    }
  },
  entities: {
    Ride: {
      create: async (data: any) => {
        const ride = { ...data, id: generateId(), created_date: new Date().toISOString() };
        mockRides.push(ride);
        return ride;
      },
      list: async (_sort?: string, _limit?: number) => mockRides,
      filter: async (query: any) => mockRides.filter(r => r.id === query.id),
      update: async (id: string, data: any) => {
        const index = mockRides.findIndex(r => r.id === id);
        if (index !== -1) {
          mockRides[index] = { ...mockRides[index], ...data };
          return mockRides[index];
        }
        return null;
      }
    },
    Delivery: {
      create: async (data: any) => {
        const delivery = { ...data, id: generateId(), created_date: new Date().toISOString() };
        mockDeliveries.push(delivery);
        return delivery;
      },
      list: async (_sort?: string, _limit?: number) => mockDeliveries,
      filter: async (query: any) => mockDeliveries.filter(d => d.id === query.id),
      update: async (id: string, data: any) => {
        const index = mockDeliveries.findIndex(d => d.id === id);
        if (index !== -1) {
          mockDeliveries[index] = { ...mockDeliveries[index], ...data };
          return mockDeliveries[index];
        }
        return null;
      }
    },
    FreightRequest: {
      create: async (data: any) => {
        const freight = { ...data, id: generateId(), created_date: new Date().toISOString() };
        mockFreights.push(freight);
        return freight;
      },
      list: async (_sort?: string, _limit?: number) => mockFreights,
      filter: async (query: any) => mockFreights.filter(f => f.id === query.id),
      update: async (id: string, data: any) => {
        const index = mockFreights.findIndex(f => f.id === id);
        if (index !== -1) {
          mockFreights[index] = { ...mockFreights[index], ...data };
          return mockFreights[index];
        }
        return null;
      }
    },
    Transaction: {
      list: async (_sort?: string, _limit?: number) => mockTransactions,
      create: async (data: any) => {
        const tx = { ...data, id: generateId(), created_date: new Date().toISOString() };
        mockTransactions.push(tx);
        return tx;
      }
    }
  }
};
